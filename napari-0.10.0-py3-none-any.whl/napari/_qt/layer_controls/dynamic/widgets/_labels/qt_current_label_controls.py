from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from qtpy.QtCore import Qt
from qtpy.QtGui import QColor, QPainter
from qtpy.QtWidgets import (
    QHBoxLayout,
    QPushButton,
    QWidget,
)
from superqt import QLargeIntSpinBox

from napari._qt.layer_controls.dynamic.widgets.qt_widget_controls_base import (
    QtWidgetControlsBase,
    QtWrappedLabel,
)
from napari._qt.utils import attr_to_settr, qt_signals_blocked
from napari.layers.labels._labels_key_bindings import new_label
from napari.layers.labels._labels_utils import get_dtype
from napari.utils._dtype import get_dtype_limits
from napari.utils.events import disconnect_events

if TYPE_CHECKING:
    from napari.layers import Labels


class QtColorBox(QWidget):
    """A widget that shows a square with the current label color.

    Parameters
    ----------
    layer : napari.layers.Labels
        An instance of a napari Labels layer.
    """

    def __init__(self, layer: Labels) -> None:
        super().__init__()

        self._layer = layer
        self._layer.events.selected_label.connect(
            self._on_selected_label_change
        )
        self._layer.events.opacity.connect(self._on_opacity_change)
        self._layer.events.colormap.connect(self._on_colormap_change)

        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)

        self._height = 24
        self.setFixedWidth(self._height)
        self.setFixedHeight(self._height)
        self.setToolTip('Selected label color')

        self.color = None

    def _on_selected_label_change(self) -> None:
        """Receive layer model label selection change event & update colorbox."""
        self.update()

    def _on_opacity_change(self) -> None:
        """Receive layer model label selection change event & update colorbox."""
        self.update()

    def _on_colormap_change(self) -> None:
        """Receive label colormap change event & update colorbox."""
        self.update()

    def paintEvent(self, event) -> None:
        """Paint the colorbox.  If no color, display a checkerboard pattern.

        Parameters
        ----------
        event : qtpy.QtCore.QEvent
            Event from the Qt context.
        """
        painter = QPainter(self)
        if self._layer._selected_color is None:
            self.color = None
            for i in range(self._height // 4):
                for j in range(self._height // 4):
                    if (i % 2 == 0 and j % 2 == 0) or (
                        i % 2 == 1 and j % 2 == 1
                    ):
                        painter.setPen(QColor(230, 230, 230))
                        painter.setBrush(QColor(230, 230, 230))
                    else:
                        painter.setPen(QColor(25, 25, 25))
                        painter.setBrush(QColor(25, 25, 25))
                    painter.drawRect(i * 4, j * 4, 5, 5)
        else:
            color = np.round(255 * self._layer._selected_color).astype(int)
            painter.setPen(QColor(*list(color)))
            painter.setBrush(QColor(*list(color)))
            painter.drawRect(0, 0, self._height, self._height)
            self.color = tuple(color)

    def disconnect_widget_controls(self) -> None:
        disconnect_events(self._layer.events, self)

    def deleteLater(self) -> None:
        self.disconnect_widget_controls()
        super().deleteLater()

    def closeEvent(self, event) -> None:
        """Disconnect events when widget is closing."""
        self.disconnect_widget_controls()
        super().closeEvent(event)


class QtCurrentLabelControls(QtWidgetControlsBase):
    """
    Class that wraps the connection of events/signals between the current label
    layer attribute and Qt widgets.

    Parameters
    ----------
    parent: qtpy.QtWidgets.QWidget
        An instance of QWidget that will be used as widgets parent
    layers : list[napari.layers.Labels]
        A list of napari Labels layers.

    Attributes
    ----------
    colorbox : QtColorBox
        Widget that shows current layer label color.
    label_color : qtpy.QtWidget.QWidget
        Wrapper widget for the selection_spinbox and colorbox widgets.
    label_color_label : napari._qt.layer_controls.widgets.qt_widget_controls_base.QtWrappedLabel
        Label for the label chooser widget.
    selection_spinbox : superqt.QLargeIntSpinBox
        Widget to select a specific label by its index.
        N.B. cannot represent labels > 2**53.
    new_label_button : qtpy.QtWidgets.QPushButton
        Button to add a new label to the label layer.
    """

    _layers: list[Labels]

    def __init__(
        self, layers: list[Labels], parent: QWidget | None = None
    ) -> None:
        super().__init__(layers, parent)
        # Setup layer
        for layer in self._layers:
            layer.events.data.connect(self._on_data_change)

        # Setup widgets
        self.selection_spinbox = QLargeIntSpinBox()
        dtype_lims = get_dtype_limits(get_dtype(self._layers[0]))
        self.selection_spinbox.setRange(*dtype_lims)
        self.selection_spinbox.setValue(self._layers[0].selected_label)
        self.selection_spinbox.setKeyboardTracking(False)
        self.selection_spinbox.valueChanged.connect(self.change_selection)
        self._callbacks.append(
            attr_to_settr(
                self._layers[0],
                'selected_label',
                self.selection_spinbox,
                'setValue',
            )
        )
        self.new_label_button = QPushButton()
        self.new_label_button.setText('new')
        self.new_label_button.setObjectName('newLabelButton')
        self.new_label_button.clicked.connect(self._on_button_click)

        self.label_color_label = QtWrappedLabel('label:')
        self.label_color = QWidget()
        color_layout = QHBoxLayout()
        color_layout.setContentsMargins(0, 2, 0, 1)
        color_layout.setSpacing(4)
        self.colorbox = QtColorBox(self._layers[0])
        color_layout.addWidget(self.colorbox, 0)
        color_layout.addWidget(self.selection_spinbox, 1)
        color_layout.addWidget(self.new_label_button, 0)
        self.label_color.setLayout(color_layout)
        self.label_color.setProperty('foreground', 'true')

    def change_selection(self, value: int) -> None:
        """Change currently selected label.
        Parameters
        ----------
        value : int
            Index of label to select.
        """
        for layer in self._layers:
            layer.selected_label = value
        self.selection_spinbox.clearFocus()
        # TODO: decouple
        if self.parent() is not None:
            self.parent().setFocus()

    def _on_data_change(self) -> None:
        """Update label selection spinbox min/max when data changes."""
        with qt_signals_blocked(self.selection_spinbox):
            dtype_lims = get_dtype_limits(get_dtype(self._layers[0]))
            self.selection_spinbox.setRange(*dtype_lims)

    def disconnect_widget_controls(self) -> None:
        self.colorbox.disconnect_widget_controls()
        super().disconnect_widget_controls()

    def _on_button_click(self):
        """Select a new label for the labels layer when the button is clicked."""
        for layer in self._layers:
            new_label(layer)

    def get_widget_controls(
        self,
    ) -> list[tuple[QtWrappedLabel, QWidget] | tuple[QWidget]]:
        return [(self.label_color_label, self.label_color)]
