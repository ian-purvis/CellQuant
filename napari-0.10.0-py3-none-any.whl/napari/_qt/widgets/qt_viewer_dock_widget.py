import warnings
from collections.abc import Sequence
from functools import reduce
from itertools import count
from operator import ior
from typing import TYPE_CHECKING, Union
from weakref import ReferenceType, ref

from qtpy.QtCore import QCoreApplication, QEvent, Qt
from qtpy.QtGui import QFontMetrics
from qtpy.QtWidgets import (
    QDockWidget,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from napari._qt.utils import combine_widgets, qt_signals_blocked
from napari.settings import get_settings

if TYPE_CHECKING:
    from magicgui.widgets import Widget

    from napari._qt.qt_viewer import QtViewer

counter = count()
_sentinel = object()

_SHORTCUT_DEPRECATION_STRING = f'The shortcut parameter is deprecated since version 0.4.8, please use the action and shortcut manager APIs. The new action manager and shortcut API allow user configuration and localisation. (got {"{shortcut}"})'

# Floor the dock keeps on itself; the contained widget's minimum is added on
# top of this by the layout (see ``event``).
_MIN_DOCK_SIZE = 50

dock_area_to_str = {
    Qt.DockWidgetArea.LeftDockWidgetArea: 'left',
    Qt.DockWidgetArea.RightDockWidgetArea: 'right',
    Qt.DockWidgetArea.TopDockWidgetArea: 'top',
    Qt.DockWidgetArea.BottomDockWidgetArea: 'bottom',
}


class QtViewerDockWidget(QDockWidget):
    """Wrap a QWidget in a QDockWidget and forward viewer events

    Parameters
    ----------
    qt_viewer : QtViewer
        The QtViewer instance that this dock widget will belong to.
    widget : QWidget or magicgui.widgets.Widget
        `widget` that will be added as QDockWidget's main widget.
    name : str
        Name of dock widget.
    area : str
        Side of the main window to which the new dock widget will be added.
        Must be in {'left', 'right', 'top', 'bottom'}
    allowed_areas : Sequence[str], optional
        Areas, relative to main window, that the widget is allowed dock.
        Each item in list must be in {'left', 'right', 'top', 'bottom'}
        By default, all areas are allowed.
    shortcut : str, optional
        Keyboard shortcut to appear in dropdown menu.
        .. deprecated:: 0.4.8

            The shortcut parameter is deprecated since version 0.4.8, please use
            the action and shortcut manager APIs. The new action manager and
            shortcut API allow user configuration and localisation.
    add_vertical_stretch : bool, optional
        Whether to add stretch to the bottom of vertical widgets (pushing
        widgets up towards the top of the allotted area, instead of letting
        them distribute across the vertical space).  By default, True.
    """

    def __init__(
        self,
        qt_viewer,
        widget: Union[QWidget, 'Widget'],
        *,
        name: str = '',
        area: str = 'right',
        allowed_areas: Sequence[str] | None = None,
        shortcut=_sentinel,
        object_name: str = '',
        add_vertical_stretch=True,
        close_btn=True,
    ) -> None:
        self._ref_qt_viewer: ReferenceType[QtViewer] = ref(qt_viewer)
        super().__init__(name)
        self._parent = qt_viewer
        self.name = name
        self._close_btn = close_btn

        areas = {
            'left': Qt.DockWidgetArea.LeftDockWidgetArea,
            'right': Qt.DockWidgetArea.RightDockWidgetArea,
            'top': Qt.DockWidgetArea.TopDockWidgetArea,
            'bottom': Qt.DockWidgetArea.BottomDockWidgetArea,
        }
        if area not in areas:
            raise ValueError(f'area argument must be in {list(areas.keys())}')
        self.area = area
        self.qt_area = areas[area]
        if shortcut is not _sentinel:
            warnings.warn(
                _SHORTCUT_DEPRECATION_STRING.format(shortcut=shortcut),
                FutureWarning,
                stacklevel=2,
            )
        else:
            shortcut = None
        self._shortcut = shortcut

        if allowed_areas:
            if not isinstance(allowed_areas, list | tuple):
                raise TypeError('`allowed_areas` must be a list or tuple')

            if any(area not in areas for area in allowed_areas):
                raise ValueError(
                    f'all allowed_areas argument must be in {list(areas.keys())}'
                )
            allowed_areas = reduce(ior, [areas[a] for a in allowed_areas])
        else:
            allowed_areas = Qt.DockWidgetArea.AllDockWidgetAreas
        self.setAllowedAreas(allowed_areas)
        self.setMinimumSize(_MIN_DOCK_SIZE, _MIN_DOCK_SIZE)
        # FIXME:
        self.setObjectName(object_name or name)

        is_vertical = area in {'left', 'right'}
        widget_ = combine_widgets(widget, vertical=is_vertical)
        self.setWidget(widget_)
        if is_vertical and add_vertical_stretch:
            self._maybe_add_vertical_stretch(widget_)

        self._features = self.features()
        self.dockLocationChanged.connect(self._set_title_orientation)

        # custom title bar
        self.title = QtCustomTitleBar(
            self,
            title=self.name,
            vertical=area in {'top', 'bottom'},
            close_btn=close_btn,
            is_floating=False,
        )
        self.setTitleBarWidget(self.title)
        self.topLevelChanged.connect(self._update_title_bar)

        self.dockLocationChanged.connect(self._update_default_dock_area)

    def inner_widget(self) -> 'QWidget | Widget':
        """The inner widget of the dock widget.

        This is the widget that was passed to the constructor
        without converting magicgui widgets to QtWidgets.
        """
        wdg = self.widget()
        if hasattr(wdg, '_magic_widget'):
            # magicgui widget, return the original widget
            return wdg._magic_widget
        # otherwise, return the widget itself
        return wdg

    def _update_default_dock_area(self, value):
        if value not in dock_area_to_str:
            return
        settings = get_settings()
        positions = settings.application.plugin_widget_positions
        area = dock_area_to_str[value]
        # Only persist positions the user chose; the initial placement must
        # not be stored, or later changes to the default would be ignored.
        if self.name not in positions and area == self.area:
            return
        positions[self.name] = area
        settings._maybe_save()

    @property
    def _parent(self):
        """
        Let's make sure parent always a weakref:

            1) parent is likely to always exists after child
            2) even if not strictly necessary it make it easier to view reference cycles.
        """
        return self._ref_parent()

    @_parent.setter
    def _parent(self, obj):
        self._ref_parent = ref(obj)

    def destroyOnClose(self):
        """Destroys dock plugin dock widget when 'x' is clicked."""
        from napari.viewer import Viewer

        viewer = self._ref_qt_viewer().viewer
        if isinstance(viewer, Viewer):
            viewer.window.remove_dock_widget(self)

    def _maybe_add_vertical_stretch(self, widget):
        """Add vertical stretch to the bottom of a vertical layout only

        ...if there is not already a widget that wants vertical space
        (like a textedit or listwidget or something).
        """
        exempt_policies = {
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.MinimumExpanding,
            QSizePolicy.Policy.Ignored,
        }
        if widget.sizePolicy().verticalPolicy() in exempt_policies:
            return

        # not uncommon to see people shadow the builtin layout() method
        # which breaks our ability to add vertical stretch...
        try:
            wlayout = widget.layout()
            if wlayout is None:
                return
        except TypeError:
            return

        for i in range(wlayout.count()):
            wdg = wlayout.itemAt(i).widget()
            if (
                wdg is not None
                and wdg.sizePolicy().verticalPolicy() in exempt_policies
            ):
                return

        # not all widgets have addStretch...
        if hasattr(wlayout, 'addStretch'):
            wlayout.addStretch(next(counter))

    @property
    def shortcut(self):
        warnings.warn(
            _SHORTCUT_DEPRECATION_STRING,
            FutureWarning,
            stacklevel=2,
        )
        return self._shortcut

    def setFeatures(self, features):
        super().setFeatures(features)
        self._features = self.features()

    def event(self, event):
        if event.type() == QEvent.Type.LayoutRequest:
            # Reset the explicit floor first so it is recomputed from
            # the content to avoid issue where minimum can only ever grow.
            self.setMinimumSize(_MIN_DOCK_SIZE, _MIN_DOCK_SIZE)
        return super().event(event)

    def keyPressEvent(self, event):
        # if you subclass QtViewerDockWidget and override the keyPressEvent
        # method, be sure to call super().keyPressEvent(event) at the end of
        # your method to pass uncaught key-combinations to the viewer.
        return self._ref_qt_viewer().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        # if you subclass QtViewerDockWidget and override the keyReleaseEvent
        # method, be sure to call super().keyReleaseEvent(event) at the end of
        # your method to pass uncaught key-combinations to the viewer.
        return self._ref_qt_viewer().keyReleaseEvent(event)

    def _set_title_orientation(self, area):
        # NoDockWidgetArea means the widget is floating; nothing to orient.
        if area == Qt.DockWidgetArea.NoDockWidgetArea:
            return
        if area in (
            Qt.DockWidgetArea.LeftDockWidgetArea,
            Qt.DockWidgetArea.RightDockWidgetArea,
        ):
            features = self._features
            if features & self.DockWidgetFeature.DockWidgetVerticalTitleBar:
                features = (
                    features
                    ^ self.DockWidgetFeature.DockWidgetVerticalTitleBar
                )
        else:
            features = (
                self._features
                | self.DockWidgetFeature.DockWidgetVerticalTitleBar
            )
        self.setFeatures(features)
        if hasattr(self, 'title'):
            vertical = self._title_bar_vertical(is_floating=False, area=area)
            if self.title.vertical != vertical:
                self._update_title_bar(False)

    @property
    def is_vertical(self):
        if not self.isFloating():
            par = self.parent()
            if par and hasattr(par, 'dockWidgetArea'):
                return par.dockWidgetArea(self) in (
                    Qt.DockWidgetArea.LeftDockWidgetArea,
                    Qt.DockWidgetArea.RightDockWidgetArea,
                )
        return self.size().height() > self.size().width()

    def _title_bar_vertical(
        self,
        *,
        is_floating: bool | None = None,
        area: Qt.DockWidgetArea | None = None,
    ) -> bool:
        if is_floating is None:
            is_floating = self.isFloating()
        if is_floating:
            return False
        if area is None:
            par = self.parent()
            if par and hasattr(par, 'dockWidgetArea'):
                area = par.dockWidgetArea(self)
        return area in (
            Qt.DockWidgetArea.TopDockWidgetArea,
            Qt.DockWidgetArea.BottomDockWidgetArea,
        )

    def _update_title_bar(self, is_floating: bool | None = None) -> None:
        """Recreate the title bar to match the current dock/float state."""
        if is_floating is None:
            is_floating = self.isFloating()
        # Floating windows always use a horizontal (non-rotated) title bar
        vertical = self._title_bar_vertical(is_floating=is_floating)
        with qt_signals_blocked(self):
            # When a widget is docked at top/bottom, Qt sets
            # DockWidgetVerticalTitleBar so the custom title bar is placed on
            # the left side of the widget. Clear that feature when floating,
            # otherwise the custom title bar ends up on the left edge of the
            # floating window as a narrow strip that is hard to drag.
            # Afterwards, recreate our custom title bar
            if is_floating:
                features = (
                    self._features
                    & ~self.DockWidgetFeature.DockWidgetVerticalTitleBar
                )
                self.setFeatures(features)
            old_title = self.titleBarWidget()
            self.setTitleBarWidget(None)
            if old_title is not None:
                old_title.setParent(None)
                old_title.deleteLater()
                QCoreApplication.sendPostedEvents(
                    None, QEvent.Type.DeferredDelete
                )
            self.title = QtCustomTitleBar(
                self,
                title=self.name,
                vertical=vertical,
                close_btn=self._close_btn,
                is_floating=is_floating,
            )
            self.setTitleBarWidget(self.title)

    def setWidget(self, widget):
        widget._parent = self
        self.setFocusProxy(widget)
        super().setWidget(widget)


class QtCustomTitleBar(QLabel):
    """A widget to be used as the titleBar in the QtViewerDockWidget.

    Keeps vertical size minimal, has a hand cursor and styles (in stylesheet)
    for hover. Close and float buttons.

    Parameters
    ----------
    parent : QDockWidget
        The QtViewerDockWidget to which this titlebar belongs
    title : str
        A string to put in the titlebar.
    vertical : bool
        Whether this titlebar is oriented vertically or not.
    """

    def __init__(
        self,
        parent,
        title: str = '',
        vertical=False,
        close_btn=True,
        is_floating=False,
    ) -> None:
        super().__init__(parent)
        self.setObjectName('QtCustomTitleBar')
        self.setProperty('vertical', str(vertical))
        self.setProperty('floating', str(is_floating))
        self.vertical = vertical
        self.setToolTip('drag to move. double-click toggles floating')

        line = QFrame(self)
        line.setObjectName('QtCustomTitleBarLine')

        self.hide_button = QPushButton(self)
        self.hide_button.setToolTip('hide this panel')
        self.hide_button.setObjectName('QTitleBarHideButton')
        self.hide_button.setCursor(Qt.CursorShape.ArrowCursor)
        self.hide_button.clicked.connect(lambda: self.parent().close())

        self.float_button = QPushButton(self)
        self.float_button.setToolTip(
            'dock this panel' if is_floating else 'float this panel'
        )
        self.float_button.setObjectName('QTitleBarFloatButton')
        self.float_button.setCursor(Qt.CursorShape.ArrowCursor)
        self.float_button.clicked.connect(
            lambda: self.parent().setFloating(not self.parent().isFloating())
        )
        self.title: QLabel = QLabel(title, self)
        self.title.setSizePolicy(
            QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        )

        if close_btn:
            self.close_button = QPushButton(self)
            self.close_button.setToolTip('close this panel')
            self.close_button.setObjectName('QTitleBarCloseButton')
            self.close_button.setCursor(Qt.CursorShape.ArrowCursor)
            self.close_button.clicked.connect(
                lambda: self.parent().destroyOnClose()
            )

        if vertical:
            layout = QVBoxLayout()
            layout.setSpacing(4)
            layout.setContentsMargins(0, 8, 0, 8)
            line.setFixedWidth(1)
            if hasattr(self, 'close_button'):
                layout.addWidget(
                    self.close_button, 0, Qt.AlignmentFlag.AlignHCenter
                )
            layout.addWidget(
                self.hide_button, 0, Qt.AlignmentFlag.AlignHCenter
            )
            layout.addWidget(
                self.float_button, 0, Qt.AlignmentFlag.AlignHCenter
            )
            layout.addWidget(line, 0, Qt.AlignmentFlag.AlignHCenter)
            self.title.hide()

        else:
            layout = QHBoxLayout()
            layout.setSpacing(4)
            layout.setContentsMargins(8, 1, 8, 0)
            line.setFixedHeight(1)
            if hasattr(self, 'close_button'):
                layout.addWidget(self.close_button)

            layout.addWidget(self.hide_button)
            layout.addWidget(self.float_button)
            layout.addWidget(line)
            layout.addWidget(self.title)
            self.title.show()

        self.setLayout(layout)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self._update_font_metrics()

    def _update_font_metrics(self) -> None:
        """Resize the title bar to fit the current font."""
        if not hasattr(self, 'title'):
            return
        # set minimum heights to ensure enough space for the title text
        font_height = QFontMetrics(self.font()).height()
        self.setMinimumHeight(font_height + 10)
        self.title.setMinimumHeight(font_height)

    def changeEvent(self, event):
        """Keep the title bar height in sync with font size changes."""
        if event.type() == QEvent.Type.FontChange:
            self._update_font_metrics()
        super().changeEvent(event)

    def sizeHint(self):
        # this seems to be the correct way to set the height of the titlebar
        # responsive to font size
        szh = super().sizeHint()
        size = QFontMetrics(self.font()).height() + 10
        if self.vertical:
            szh.setWidth(size)
        else:
            szh.setHeight(size)
        return szh
