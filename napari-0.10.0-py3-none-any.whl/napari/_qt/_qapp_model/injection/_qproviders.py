"""Qt providers.

Any non-Qt providers should be added inside `napari/_app_model/injection/`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from napari import components, layers, viewer
from napari._app_model import get_app_model
from napari.utils._proxies import PublicOnlyProxy
from napari.utils.events.containers._selection import Selection
from napari.viewer import ViewerModel

if TYPE_CHECKING:
    from collections.abc import Callable

    from napari._qt.qt_main_window import Window
    from napari._qt.qt_viewer import QtViewer


def _provide_viewer(public_proxy: bool = True) -> viewer.Viewer | None:
    """Provide `PublicOnlyProxy` (allows internal napari access) of current viewer."""
    if current_viewer := viewer.current_viewer():
        if public_proxy:
            return PublicOnlyProxy(current_viewer)
        return current_viewer
    return None


def _provide_viewer_model(public_proxy: bool = True) -> ViewerModel | None:
    """Provide a Viewer (subclass of ViewerModel) if ViewerModel is needed."""
    return _provide_viewer(public_proxy)


def _provide_viewer_or_raise(
    msg: str = '', public_proxy: bool = False
) -> viewer.Viewer:
    viewer = _provide_viewer(public_proxy)
    if viewer:
        return viewer
    if msg:
        msg = ' ' + msg
    raise RuntimeError(f'No current `Viewer` found.{msg}')


def _provide_qt_viewer() -> QtViewer | None:
    from napari._qt.qt_main_window import _QtMainWindow

    if _qmainwin := _QtMainWindow.current():
        return _qmainwin._qt_viewer
    return None


def _provide_qt_viewer_or_raise(msg: str = '') -> QtViewer:
    qt_viewer = _provide_qt_viewer()
    if qt_viewer:
        return qt_viewer
    if msg:
        msg = ' ' + msg
    raise RuntimeError(f'No current `QtViewer` found.{msg}')


def _provide_window() -> Window | None:
    from napari._qt.qt_main_window import _QtMainWindow

    if _qmainwin := _QtMainWindow.current():
        return _qmainwin._window
    return None


def _provide_window_or_raise(msg: str = '') -> Window:
    window = _provide_window()
    if window:
        return window
    if msg:
        msg = ' ' + msg
    raise RuntimeError(f'No current `Window` found.{msg}')


def _provide_active_layer() -> layers.Layer | None:
    return v.layers.selection.active if (v := _provide_viewer()) else None


def _provide_selected_layers() -> Selection[layers.Layer] | None:
    return v.layers.selection if (v := _provide_viewer()) else None


def _provide_active_layer_list() -> components.LayerList | None:
    return v.layers if (v := _provide_viewer()) else None


def register_qt_types() -> None:
    from napari._qt.qt_viewer import QtViewer

    app = get_app_model()
    if 'QtViewer' not in app.injection_store.namespace:
        app.injection_store.namespace = {
            **app.injection_store.namespace,
            'QtViewer': QtViewer,
        }


# syntax could be simplified after
# https://github.com/tlambert03/in-n-out/issues/31
QPROVIDERS: list[tuple[Callable]] = [
    (_provide_viewer,),
    (_provide_viewer_model,),
    (_provide_qt_viewer,),
    (_provide_window,),
    (_provide_active_layer,),
    (_provide_active_layer_list,),
    (_provide_selected_layers,),
]
