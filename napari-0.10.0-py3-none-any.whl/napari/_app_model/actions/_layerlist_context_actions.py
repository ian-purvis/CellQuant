"""This module defines actions (functions) that operate on layers and its submenus.

Among other potential uses, these will populate the menu when you right-click
on a layer in the LayerList.

The Actions in LAYER_ACTIONS are registered with the application when it is
created in `_app_model._app`.  Modifying this list at runtime will have no
effect.  Use `app.register_action` to register new actions at runtime.
"""

from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING

from app_model.types import Action, SubmenuItem, ToggleRule

from napari._app_model.constants import MenuGroup, MenuId
from napari._app_model.context import LayerListSelectionContextKeys as LLSCK
from napari.layers import _layer_actions

if TYPE_CHECKING:
    from app_model.types import MenuRuleDict

# Projections need a layer with more than 2 dimensions.
_ACTIVE_IMAGE_ND = (LLSCK.active_layer_type == 'image') & (
    LLSCK.active_layer_ndim > 2
)
_ACTIVE_POINTS_ND = (LLSCK.active_layer_type == 'points') & (
    LLSCK.active_layer_ndim > 2
)

# Layer submenus
LAYERLIST_CONTEXT_SUBMENUS = [
    (
        MenuId.LAYERLIST_CONTEXT,
        SubmenuItem(
            submenu=MenuId.LAYERS_CONTEXT_CONVERT_DTYPE,
            title='Convert data type',
            group=MenuGroup.LAYERLIST_CONTEXT.CONVERSION,
            order=None,
            enablement=LLSCK.all_selected_layers_labels,
        ),
    ),
    (
        MenuId.LAYERLIST_CONTEXT,
        SubmenuItem(
            submenu=MenuId.LAYERS_CONTEXT_PROJECT,
            title='Projections',
            group=MenuGroup.LAYERLIST_CONTEXT.SPLIT_MERGE,
            order=None,
            enablement=(_ACTIVE_IMAGE_ND | _ACTIVE_POINTS_ND),
        ),
    ),
    (
        MenuId.LAYERLIST_CONTEXT,
        SubmenuItem(
            submenu=MenuId.LAYERS_CONTEXT_COPY_SPATIAL,
            title='Copy scale and transforms',
            group=MenuGroup.LAYERLIST_CONTEXT.COPY_SPATIAL,
            order=None,
            enablement=(LLSCK.num_selected_layers == 1),
        ),
    ),
    (
        MenuId.LAYERLIST_CONTEXT,
        SubmenuItem(
            submenu=MenuId.LAYERS_CONTEXT_VISUALIZATION,
            title='Visualization',
            group=MenuGroup.LAYERLIST_CONTEXT.COPY_SPATIAL,
            order=None,
        ),
    ),
]

# The following dicts define groups to which menu items in the layer list context menu can belong
# see https://app-model.readthedocs.io/en/latest/types/#app_model.types.MenuRule for details
LAYERCTX_SPLITMERGE: MenuRuleDict = {
    'id': MenuId.LAYERLIST_CONTEXT,
    'group': MenuGroup.LAYERLIST_CONTEXT.SPLIT_MERGE,
}
LAYERCTX_CONVERSION: MenuRuleDict = {
    'id': MenuId.LAYERLIST_CONTEXT,
    'group': MenuGroup.LAYERLIST_CONTEXT.CONVERSION,
}
LAYERCTX_LINK: MenuRuleDict = {
    'id': MenuId.LAYERLIST_CONTEXT,
    'group': MenuGroup.LAYERLIST_CONTEXT.LINK,
}

# Statically defined Layer actions.
# modifying this list at runtime has no effect.
LAYERLIST_CONTEXT_ACTIONS: list[Action] = [
    Action(
        id='napari.layer.duplicate',
        title='Duplicate Layer',
        callback=_layer_actions._duplicate_layer,
        menus=[LAYERCTX_SPLITMERGE],
    ),
    Action(
        id='napari.layer.split_stack',
        title='Split Stack',
        callback=_layer_actions._split_stack,
        menus=[{**LAYERCTX_SPLITMERGE, 'when': ~LLSCK.active_layer_is_rgb}],
        enablement=(
            _ACTIVE_IMAGE_ND & ~LLSCK.any_selected_layers_deletion_locked
        ),
    ),
    Action(
        id='napari.layer.split_rgb',
        title='Split RGB',
        callback=_layer_actions._split_rgb,
        menus=[{**LAYERCTX_SPLITMERGE, 'when': LLSCK.active_layer_is_rgb}],
        enablement=(
            LLSCK.active_layer_is_rgb
            & ~LLSCK.any_selected_layers_deletion_locked
        ),
    ),
    Action(
        id='napari.layer.merge_rgb',
        title='Merge to RGB',
        callback=partial(_layer_actions._merge_stack, rgb=True),
        enablement=(
            (
                (LLSCK.num_selected_layers == 3)
                | (LLSCK.num_selected_layers == 4)
            )
            & (LLSCK.num_selected_image_layers == LLSCK.num_selected_layers)
            & LLSCK.all_selected_layers_same_shape
            & ~LLSCK.any_selected_layers_deletion_locked
        ),
        menus=[LAYERCTX_SPLITMERGE],
    ),
    Action(
        id='napari.layer.convert_to_labels',
        title='Convert to Labels',
        callback=_layer_actions._convert_to_labels,
        enablement=(
            (
                (LLSCK.num_selected_image_layers >= 1)
                | (LLSCK.num_selected_shapes_layers >= 1)
            )
            & LLSCK.all_selected_layers_same_type
            & ~LLSCK.selected_empty_shapes_layer
            & ~LLSCK.any_selected_layers_deletion_locked
        ),
        menus=[LAYERCTX_CONVERSION],
    ),
    Action(
        id='napari.layer.convert_to_image',
        title='Convert to Image',
        callback=_layer_actions._convert_to_image,
        enablement=(
            (LLSCK.num_selected_labels_layers >= 1)
            & LLSCK.all_selected_layers_same_type
            & ~LLSCK.any_selected_layers_deletion_locked
        ),
        menus=[LAYERCTX_CONVERSION],
    ),
    Action(
        id='napari.layer.merge_stack',
        title='Merge to Stack',
        callback=_layer_actions._merge_stack,
        enablement=(
            (LLSCK.num_selected_layers > 1)
            & (LLSCK.num_selected_image_layers == LLSCK.num_selected_layers)
            & LLSCK.all_selected_layers_same_shape
            & ~LLSCK.any_selected_layers_deletion_locked
        ),
        menus=[LAYERCTX_SPLITMERGE],
    ),
    Action(
        id='napari.layer.toggle_visibility',
        title='Toggle visibility',
        callback=_layer_actions._toggle_visibility,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.NAVIGATION,
            }
        ],
    ),
    Action(
        id='napari.layer.link_selected_layers',
        title='Link Layers',
        callback=_layer_actions._link_selected_layers,
        enablement=(
            (LLSCK.num_selected_layers > 1) & ~LLSCK.num_selected_layers_linked
        ),
        menus=[{**LAYERCTX_LINK, 'when': ~LLSCK.num_selected_layers_linked}],
    ),
    Action(
        id='napari.layer.unlink_selected_layers',
        title='Unlink Layers',
        callback=_layer_actions._unlink_selected_layers,
        enablement=LLSCK.num_selected_layers_linked,
        menus=[{**LAYERCTX_LINK, 'when': LLSCK.num_selected_layers_linked}],
    ),
    Action(
        id='napari.layer.select_linked_layers',
        title='Select Linked Layers',
        callback=_layer_actions._select_linked_layers,
        enablement=LLSCK.num_unselected_linked_layers,
        menus=[LAYERCTX_LINK],
    ),
    Action(
        id='napari.layer.toggle_lock',
        title='Toggle lock',
        callback=_layer_actions._toggle_lock,
        menus=[LAYERCTX_LINK],
    ),
    Action(
        id='napari.layer.show_selected',
        title='Show All Selected Layers',
        callback=_layer_actions._show_selected,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.NAVIGATION,
            }
        ],
    ),
    Action(
        id='napari.layer.hide_selected',
        title='Hide All Selected Layers',
        callback=_layer_actions._hide_selected,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.NAVIGATION,
            }
        ],
    ),
    Action(
        id='napari.layer.show_unselected',
        title='Show All Unselected Layers',
        callback=_layer_actions._show_unselected,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.NAVIGATION,
            }
        ],
    ),
    Action(
        id='napari.layer.hide_unselected',
        title='Hide All Unselected Layers',
        callback=_layer_actions._hide_unselected,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.NAVIGATION,
            }
        ],
    ),
    Action(
        id='napari.layer.bounding_box',
        title='Bounding Box',
        callback=_layer_actions._toggle_bounding_box,
        menus=[MenuId.LAYERS_CONTEXT_VISUALIZATION, MenuId.LAYERS_VISUALIZE],
        enablement=LLSCK.num_selected_layers > 0,
        toggled=ToggleRule(
            get_current=_layer_actions._are_bounding_boxes_visible
        ),
    ),
    Action(
        id='napari.layer.colorbar',
        title='Colorbar',
        callback=_layer_actions._toggle_colorbar,
        menus=[MenuId.LAYERS_CONTEXT_VISUALIZATION, MenuId.LAYERS_MEASURE],
        enablement=(
            (LLSCK.num_selected_layers > 0)
            & LLSCK.all_selected_layers_support_colorbar
        ),
        toggled=ToggleRule(get_current=_layer_actions._are_colorbars_visible),
    ),
    Action(
        id='napari.layer.border_colorbar',
        title='Border Colorbar',
        callback=_layer_actions._toggle_border_colorbar,
        menus=[MenuId.LAYERS_CONTEXT_VISUALIZATION, MenuId.LAYERS_MEASURE],
        enablement=(
            (LLSCK.num_selected_layers > 0)
            & LLSCK.all_selected_layers_support_border_colorbar
        ),
        toggled=ToggleRule(
            get_current=_layer_actions._are_border_colorbars_visible
        ),
    ),
    Action(
        id='napari.layer.face_colorbar',
        title='Face Colorbar',
        callback=_layer_actions._toggle_face_colorbar,
        menus=[MenuId.LAYERS_CONTEXT_VISUALIZATION, MenuId.LAYERS_MEASURE],
        enablement=(
            (LLSCK.num_selected_layers > 0)
            & LLSCK.all_selected_layers_support_face_colorbar
        ),
        toggled=ToggleRule(
            get_current=_layer_actions._are_face_colorbars_visible
        ),
    ),
    Action(
        id='napari.layer.name_overlay',
        title='Name Overlay',
        callback=_layer_actions._toggle_name_overlay,
        menus=[MenuId.LAYERS_CONTEXT_VISUALIZATION, MenuId.LAYERS_VISUALIZE],
        enablement=(LLSCK.num_selected_layers > 0),
        toggled=ToggleRule(
            get_current=_layer_actions._are_name_overlays_visible
        ),
    ),
    Action(
        id='napari.layer.extract_multiscale_level',
        title='New layer from selected multiscale level',
        callback=_layer_actions._extract_multiscale_level_from_selection,
        menus=[
            {
                'id': MenuId.LAYERLIST_CONTEXT,
                'group': MenuGroup.LAYERLIST_CONTEXT.SPLIT_MERGE,
                'when': LLSCK.single_selected_multiscale_layer_locked_data_level,
            }
        ],
    ),
]

for _dtype in (
    'int8',
    'int16',
    'int32',
    'int64',
    'uint8',
    'uint16',
    'uint32',
    'uint64',
):
    LAYERLIST_CONTEXT_ACTIONS.append(
        Action(
            id=f'napari.layer.convert_to_{_dtype}',
            title=f'Convert to {_dtype}',
            callback=partial(_layer_actions._convert_dtype, mode=_dtype),
            enablement=(
                LLSCK.all_selected_layers_labels
                & (LLSCK.active_layer_dtype != _dtype)
            ),
            menus=[{'id': MenuId.LAYERS_CONTEXT_CONVERT_DTYPE}],
        )
    )

for mode in ('max', 'min', 'std', 'sum', 'mean', 'median'):
    LAYERLIST_CONTEXT_ACTIONS.append(
        Action(
            id=f'napari.layer.project_{mode}',
            title=f'{mode} projection',
            callback=partial(_layer_actions._project, mode=mode),
            enablement=_ACTIVE_IMAGE_ND,
            menus=[
                {'id': MenuId.LAYERS_CONTEXT_PROJECT, 'when': _ACTIVE_IMAGE_ND}
            ],
        )
    )

# Points have no reduction mode: a single entry in the same Projections submenu
# that drops the leading axis.
LAYERLIST_CONTEXT_ACTIONS.append(
    Action(
        id='napari.layer.project_points_single_plane',
        title='Drop first axis',
        callback=_layer_actions._project_points,
        enablement=_ACTIVE_POINTS_ND,
        menus=[
            {'id': MenuId.LAYERS_CONTEXT_PROJECT, 'when': _ACTIVE_POINTS_ND}
        ],
    )
)
