"""The Window class is the primary entry to the napari GUI.

Currently, this module is just a stub file that will simply pass through the
:class:`napari._qt.qt_main_window.Window` class.  In the future, this module
could serve to define a window Protocol that a backend would need to implement
to server as a graphical user interface for napari.
"""

from typing import Any, NoReturn

__all__ = ['Window']


try:
    from napari._qt import Window

except ImportError as e:
    err = e

    class Window:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def close(self) -> None:
            pass

        def __getattr__(self, name: str) -> NoReturn:
            raise type(err)(
                'An error occured when importing Qt dependencies.  Cannot show napari window.  See cause above'
            ) from err
