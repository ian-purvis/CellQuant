from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from vispy.scene.visuals import Rectangle
from vispy.visuals.transforms import MatrixTransform, STTransform

from napari._vispy.utils.gl import BLENDING_MODES
from napari.utils.color import (
    ColorValue,
    _contrasting_color,
    _readable_color,
)
from napari.utils.events import disconnect_events

if TYPE_CHECKING:
    from vispy.scene import Node, ViewBox

    from napari._vispy.utils.qt_font import FontInfo
    from napari.components.overlays import CanvasOverlay, Overlay, SceneOverlay
    from napari.components.viewer_model import ViewerModel
    from napari.layers import Layer
    from napari.utils.events import Event


class VispyBaseOverlay:
    """
    Base overlay backend for vispy.

    Creates event connections between napari Overlay models and the
    vispy backend, translating them into rendering.
    """

    overlay: Overlay

    def __init__(
        self,
        *,
        overlay: Overlay,
        font_info: FontInfo,
        viewer: ViewerModel,
        node: Node,
        parent: ViewBox | None = None,
    ) -> None:
        super().__init__()
        self.overlay = overlay
        self._font_info = font_info
        self._default_font_size = 9
        self.viewer = viewer

        self.node = node
        self.node.order = self.overlay.order

        self.overlay.events.visible.connect(self._on_visible_change)
        self.overlay.events.opacity.connect(self._on_opacity_change)
        self.overlay.events.blending.connect(self._on_blending_change)

        if parent is not None:
            self.node.parent = parent

    def _should_be_visible(self) -> bool:
        return self.overlay.visible

    def _on_visible_change(self) -> None:
        self.node.visible = self._should_be_visible()

    def _on_opacity_change(self) -> None:
        self.node.opacity = self.overlay.opacity

    def _on_blending_change(self) -> None:
        self.node.set_gl_state(**BLENDING_MODES[self.overlay.blending])
        self.node.update()

    def _get_bgcolor(self) -> ColorValue:
        return self.viewer.canvas.background_color

    def _get_fgcolor(self) -> ColorValue:
        bgcolor = self._get_bgcolor()
        return _readable_color(_contrasting_color(bgcolor), bgcolor)

    def _on_font_size_change(self) -> None:
        # to be implemented by subclasses that need it
        pass

    def set_default_font_size(self, font_size: int) -> None:
        self._default_font_size = font_size
        self._on_font_size_change()

    def reset(self) -> None:
        self._on_visible_change()
        self._on_opacity_change()
        self._on_blending_change()
        self._on_font_size_change()

    def close(self) -> None:
        self.overlay.events.visible.disconnect(self._on_visible_change)
        self.overlay.events.opacity.disconnect(self._on_opacity_change)
        self.overlay.events.blending.disconnect(self._on_blending_change)
        disconnect_events(self.viewer.events, self)
        disconnect_events(self.viewer.canvas.events, self)
        disconnect_events(self.viewer.dims.events, self)
        disconnect_events(self.viewer.scene.events, self)
        disconnect_events(self.viewer.scene.camera.events, self)
        disconnect_events(self.viewer.canvas.grid.events, self)
        disconnect_events(self.viewer.cursor.events, self)
        self.node.transforms = MatrixTransform()
        self.node.parent = None


class VispyCanvasOverlay(VispyBaseOverlay):
    """
    Vispy overlay backend for overlays that live in canvas space.

    NOTE: Subclasses must follow some rules:
    - ensure that when `_on_position_change` is called, the x_size and y_size
      attributes are already updated depending on the overlay size, to ensure
      proper tiling. Alternatively, override this method if the overlay is
      *not* supposed to be tiled
    - ensure that the napari Overlay model uses the `position` field correctly
      (must be a CanvasPosition enum if tileable, or anything else if "free")
    """

    overlay: CanvasOverlay

    def __init__(self, **kwargs: Any) -> None:

        super().__init__(**kwargs)
        self.x_size = 0.0
        self.y_size = 0.0
        self.node.transform = STTransform()
        self.overlay.events.position.connect(self._on_position_change)
        self.overlay.events.box.connect(self._on_box_change)
        self.overlay.events.box_color.connect(self._on_box_change)

        self.viewer.canvas.events.background_color.connect(self._on_box_change)
        self.viewer.canvas.overlay_tiling.events.padding.connect(
            self._on_box_change
        )

        self.box = Rectangle(center=(0, 0), border_width=0)

    def _on_visible_change(self) -> None:
        super()._on_visible_change()
        self._on_box_change()

    def _on_box_change(self) -> None:
        if not self.overlay.box or not self._should_be_visible():
            self.box.parent = None
            return

        self.box.parent = self.node.parent

        pad_x, pad_y = (
            np.array(self.viewer.canvas.overlay_tiling.padding) * 0.8
        )
        self.box.width = self.x_size + pad_x
        self.box.height = self.y_size + pad_y
        self.box.center = self.x_size / 2, self.y_size / 2

        if self.overlay.box_color is None:
            bgcolor = self.viewer.canvas.background_color
            # make the color a bit transparent
            bgcolor[-1] *= 0.8
        else:
            bgcolor = self.overlay.box_color

        self.box.color = bgcolor

        self.box.order = self.node.order - 1
        self.box.transform = self.node.transform

    def _get_bgcolor(self) -> ColorValue:
        if not self.overlay.box or self.overlay.box_color is None:
            return super()._get_bgcolor()
        return self.overlay.box_color

    def _on_blending_change(self) -> None:
        self.box.set_gl_state(**BLENDING_MODES[self.overlay.blending])
        super()._on_blending_change()

    def _on_position_change(self, event: Event | None = None) -> None:
        # NOTE: when subclasses call this method, they should first ensure sizes
        # (x_size, and y_size) are set correctly
        self._on_box_change()
        self.viewer.canvas.events._overlay_positions_changed()

    def reset(self) -> None:
        super().reset()
        self._on_position_change()

    def close(self) -> None:
        super().close()
        self.box.parent = None


class VispySceneOverlay(VispyBaseOverlay):
    """
    Vispy overlay backend for overlays that live in scene (2D or 3D) space.
    """

    overlay: SceneOverlay

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.node.transform = MatrixTransform()


class LayerOverlayMixin(VispyBaseOverlay):
    layer: Layer

    def __init__(self, *, layer: Layer, **kwargs: Any) -> None:
        self.layer = layer
        super().__init__(
            **kwargs,
        )
        # need manual connection here because these overlays are not necessarily
        # always a child of the actual vispy node of the layer (eg, canvas overlays)
        self.layer.events.visible.connect(self._on_visible_change)

    def _should_be_visible(self) -> bool:
        return self.overlay.visible and self.layer.visible

    def close(self) -> None:
        disconnect_events(self.layer.events, self)
        super().close()


class ViewerOverlayMixin:
    pass
