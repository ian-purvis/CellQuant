from cellquant.plugin.capabilities import detect_runtime_capabilities


def test_detects_v4_cpu_only_environment():
    caps = detect_runtime_capabilities(
        cellpose_version_fn=lambda: "4.2.1.1",
        cuda_fn=lambda: (False, "2.14.0+cpu", "PyTorch is a CPU-only build"),
    )
    assert caps.cellpose_major == 4
    assert caps.cuda_available is False
    assert [engine.engine_id for engine in caps.available_engines] == ["v4"]
    assert [device.device_id for device in caps.available_devices] == ["auto", "cpu"]
    assert caps.default_device_id == "auto"
    assert "CPU only" in caps.summary
    # Classic v3 is catalogued but not offered when Cellpose 4.x is installed.
    v3 = next(engine for engine in caps.engines if engine.engine_id == "v3")
    assert v3.available is False
    assert "Requires Cellpose 3" in (v3.unavailable_reason or "")


def test_detects_cuda_device_options_when_available():
    caps = detect_runtime_capabilities(
        cellpose_version_fn=lambda: "4.0.1",
        cuda_fn=lambda: (True, "2.4.0+cu121", "NVIDIA GeForce"),
    )
    assert [device.device_id for device in caps.available_devices] == ["auto", "cuda", "cpu"]
    assert caps.default_device_id == "auto"
    assert "GPU available" in caps.summary


def test_v3_only_env_has_no_runnable_cellquant_engine_yet():
    caps = detect_runtime_capabilities(
        cellpose_version_fn=lambda: "3.1.0",
        cuda_fn=lambda: (True, "2.1.0", "GPU"),
    )
    assert caps.available_engines == ()
    assert "no CellQuant-supported engine" in caps.summary
    v3 = next(engine for engine in caps.engines if engine.engine_id == "v3")
    assert "not yet supported" in (v3.unavailable_reason or "")
