import numpy as np
import pytest

from cellquant.contracts import LabelVolume
from cellquant.postprocess import filter_size, merge_labels, relabel, remove_border_labels, split_label


def _labels():
    data = np.zeros((3, 6, 7), dtype=np.uint32)
    data[0:2, 0:2, 0:2] = 2
    data[1:3, 3:6, 3:7] = 9
    data[1, 2, 2] = 20
    return LabelVolume(data, (2, 0.5, 0.5))


def test_volume_and_voxel_filters_are_distinct():
    result = filter_size(_labels(), {"min_volume_um3": 2, "max_volume_um3": None,
                                     "min_voxels": None, "max_voxels": None})
    assert set(np.unique(result.data)) == {0, 2, 9}


def test_border_faces_are_explicit():
    result = remove_border_labels(_labels(), ["z0"])
    assert 2 not in np.unique(result.data) and 9 in np.unique(result.data)
    with pytest.raises(ValueError, match="unknown"):
        remove_border_labels(_labels(), ["all"])


def test_relabel_merge_and_split_preserve_uint32():
    compact = relabel(_labels())
    assert set(np.unique(compact.data)) == {0, 1, 2, 3}
    merged = merge_labels(compact, [(1, 3)])
    assert set(np.unique(merged.data)) == {0, 1, 2}
    parts = np.zeros_like(merged.data)
    coords = np.argwhere(merged.data == 1)
    for index, coord in enumerate(coords):
        parts[tuple(coord)] = 1 if index < len(coords) // 2 else 2
    split = split_label(merged, {"label": 1, "parts": parts})
    assert split.data.dtype == np.uint32
    assert len(np.unique(split.data[split.data > 0])) == 3

