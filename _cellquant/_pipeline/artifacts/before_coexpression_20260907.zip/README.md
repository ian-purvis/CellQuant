# CellQuant

CellQuant is a napari plugin and command-line tool for nucleus segmentation
(Cellpose-SAM) and per-object measurement on 2D or 3D fluorescence images.
The GUI and CLI share the same calibrated analysis core.

Supported inputs include TIFF, OME-TIFF, and ND2. Outputs are label masks,
measurement tables, QC figures, and a full provenance record for each run.

For the scientific parity contract, package boundaries, and verification
gates, see [`ARCHITECTURE.md`](ARCHITECTURE.md). Measured validation status
lives in [`docs/STATUS.json`](docs/STATUS.json).

---

## Requirements

- **Python 3.11**
- **napari** (installed with CellQuant)
- Optional but recommended for large volumes: a **CUDA-capable GPU** and a
  driver-compatible PyTorch build
- On Windows, **Miniconda**, **Miniforge**, or **Anaconda** if you use the
  provided install/launch scripts

Review voxel spacing, segmentation channel, anisotropy, device, and model
path/hash in your config before each acquisition or campaign.

---

## Install

### Windows (recommended)

Double-click **`Install CellQuant.bat`**, or from PowerShell:

```powershell
.\scripts\install_windows.ps1
```

The installer asks where to put the conda environment (napari lives there
too). Press Enter for the default
(`<conda-base>\envs\cellquant-napari`), or paste any writable folder such as
`D:\Software\cellquant-napari`. You can also pass a path directly:

```bat
Install CellQuant.bat "D:\Software\cellquant-napari"
```

```powershell
.\scripts\install_windows.ps1 -Prefix "D:\Software\cellquant-napari"
```

The chosen path is saved in `cellquant_env.json` so **Open CellQuant.bat**
uses the same location. On a GPU workstation, install a CUDA-enabled
PyTorch build that matches your driver before or right after this step; the
generic PyPI torch wheel may be CPU-only.

### Any platform (pip)

```bash
python -m pip install -e ".[test]"
```

Use a dedicated virtual environment or conda env with Python 3.11.

---

## How to open it

### Option A — Double-click (Windows)

1. Double-click **`Open CellQuant.bat`** in this folder.
2. Wait for the napari window to appear.
3. In napari, open **Plugins → CellQuant Cellpose Pipeline**.

If the launcher reports that the environment is missing, run
**`Install CellQuant.bat`** once (and choose an install folder), then try again.

You can pin `Open CellQuant.bat` to the taskbar or create a desktop shortcut
to it for quicker access.

### Option B — PowerShell launcher

```powershell
.\scripts\launch_napari.ps1
```

### Option C — Already-known environment

If you installed to a custom folder (see `cellquant_env.json`):

```bash
conda activate "D:\Software\cellquant-napari"   # your chosen path
napari
```

Then choose **Plugins → CellQuant Cellpose Pipeline**.

---

## Using the napari plugin

Open **Plugins → CellQuant Cellpose Pipeline**, then choose a **Mode**:

### Batch folder

1. Choose input/output folders, file type (e.g. ND2), and recursive
2. Click **Survey folder** — CellQuant clusters files by channel layout and
   **writes + auto-loads** `<output>/survey/cellquant_run_config.yaml` (from the
   bundled `sample_config.yaml`; you do not browse for a config)
3. For each layout, include it and pick the **segmentation channel** (any
   channel — nuclear or cytoplasmic; name hints are optional defaults only)
4. Click **Run batch** — one queue per layout; per-layout YAMLs are written under
   `<output>/survey/configs/`

### Single image

- opens TIFF / OME-TIFF / ND2 lazily into **CellQuant image**
- uses the bundled sample config automatically (no config file picker)
- pick segmentation channel from the image metadata dropdown, then Run Cellpose
- measure/save writes a run store; a run config is materialized in the output
  folder if needed

Cellpose’s main `model.eval` call is a single blocking step; cancel takes
effect at the checkpoints around it, not mid-eval.

---

## Headless commands

With CellQuant installed and on your `PATH` (or inside the conda env):

```bash
cellquant survey INPUT_DIR SURVEY_OUT --recursive --file-type nd2
cellquant survey-run SURVEY_OUT/survey.json BATCH_OUT --config your_config.yaml --assignments SURVEY_OUT/assignments.csv
cellquant batch INPUT_DIR OUTPUT_DIR --config your_config.yaml --recursive --file-type tiff
cellquant harness STACK.tif CASE_OUTPUT --config your_config.yaml
cellquant parity REFERENCE_LABELS CANDIDATE_LABELS REPORT_DIR
cellquant showcase preprocess STACK.tif SHOWCASE_DIR --config your_config.yaml --crop 0:8,0:256,0:256
```

- `survey` clusters acquisitions by channel layout; edit `assignments.csv` (or
  use the napari Survey UI) before `survey-run`.
- Batch discovers supported images under the input path. Use `--recursive` /
  `--no-recursive` to override `io.recursive`, and `--file-type {all,tiff,nd2}`
  or `--suffixes .tif .nd2` to override `io.suffixes`.
- Batch outputs mirror input parents (for example `sample.tif.cellquant`).
- A file resumes only when content/size/mtime and full config fingerprints
  match a validated completion marker.
- A failed file writes a failure record and does not stop the rest of the queue.
- `parity` accepts two label TIFFs or two directories; candidate batch trees are
  recognized via `*.cellquant/labels.tif`.

---

## Configuration

- Use **`sample_config.yaml`** as the full schema example for new projects.
- Use **`reference_config.yaml`** only when you intentionally want the
  documented Fiji/notebook-compatible profile for the lab reference corpus.

Configs are validated and versioned. Model weights can be pinned by SHA-256;
a hash mismatch fails the run instead of silently substituting another file.

**Cellpose engine (napari):** the dock probes the active environment at startup and
lists only engines this computer can run (today: Cellpose-SAM v4 when Cellpose 4.x
is installed). Device choices are filtered the same way — CUDA appears only when
a CUDA-capable PyTorch build is available. Your current env summary is shown at
the top of the segmentation options.

The Cellpose **engine is pinned in the scientific core to Cellpose-SAM (v4)** for
parity (`segment.engine: v4`). Classic Cellpose 3.x may be detected and explained
in the UI, but is not offered until a dedicated adapter is added.

**Diameter (Cellpose-SAM):** unlike older Cellpose, v4 does **not** auto-estimate
object size. Prefer **Native** (`diameter_px: null`) to run without rescaling.
Use **Manual** only when you know a typical width in pixels, or measure it in
napari (**Add measure layer** → draw a line across a nucleus → **Use drawn line**).
A larger manual diameter downsamples (often faster; can merge small objects).

Hover any dock control for a short explanation of that parameter.

Segmentation modes:

| Mode | Role |
| --- | --- |
| `volume_3d` | Full 3D Cellpose (`do_3D=True`) |
| `stitch_2d` | Per-plane 2D + Z stitching (`stitch_threshold` allowed) |
| `single_plane_2d` | One explicit zero-based `segment.z_index` |
| `max_projection_2d` | Max-Z projection, then 2D segmentation |

Only `stitch_2d` may use a nonzero `stitch_threshold`. Single-plane and
max-projection runs produce singleton-Z labels; their morphology table still
reports a singleton-Z `volume_um3`, which is **not** a true 3D object volume.

One channel drives segmentation per run. To segment several channels from one
image, run them separately with different channel selections and separate
output directories.

---

## Data contracts (short)

| Item | Contract |
| --- | --- |
| Images | `(Z, Y, X, C)`; source intensity dtype preserved at I/O |
| Labels | `(Z, Y, X)` `uint32`; background `0` |
| Spacing | Positive `(z_um, y_um, x_um)` metadata — never inferred from name/shape |
| Discovery | `io.recursive` plus `io.suffixes` (subset of `.tif` / `.tiff` / `.nd2`) |
| Provenance | Config, fingerprints, events, environment inventory, atomic status marker |

Disabled transforms remain explicit in the serialized config. Every consumed
Cellpose argument is recorded.

---

## Further reading

- [`ARCHITECTURE.md`](ARCHITECTURE.md) — scientific contract and package APIs
- [`docs/STATUS.json`](docs/STATUS.json) — measured gates and open issues
- [`docs/CUDA_GAUNTLET.md`](docs/CUDA_GAUNTLET.md) — GPU validation checklist
