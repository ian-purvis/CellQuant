"""npe2/magicgui widget factory for the CellQuant plugin."""

from pathlib import Path

from cellquant.config import load_config
from cellquant.io import resolve_file_type_preset
from cellquant.survey import default_template_config_path, materialize_run_config

from .capabilities import RuntimeCapabilities, detect_runtime_capabilities
from .controller import PluginController
from .diameter import DIAMETER_SHAPES_LAYER, diameter_from_shapes_layer
from .help_text import tip
from .messages import open_path_in_os
from .paths import require_existing_dir, require_existing_file


SEGMENTATION_CHANNEL_WIDGET_OPTIONS = {
    "widget_type": "ComboBox",
    "choices": [],
    "label": "Segmentation channel",
}

FILE_TYPE_CHOICES = (
    "All supported",
    "TIFF (.tif/.tiff)",
    "ND2 (.nd2)",
)

_FILE_TYPE_TO_PRESET = {
    "All supported": "all",
    "TIFF (.tif/.tiff)": "tiff",
    "ND2 (.nd2)": "nd2",
}

SEGMENT_MODE_CHOICES = (
    ("3D volume (Cellpose do_3D)", "volume_3d"),
    ("2D planes + Z stitch", "stitch_2d"),
    ("Single Z plane (2D)", "single_plane_2d"),
    ("Max Z projection (2D)", "max_projection_2d"),
)

DIAMETER_MODE_CHOICES = (
    ("Native — no rescale (recommended)", "native"),
    ("Manual — diameter in pixels", "manual"),
)


def segmentation_channel_choices(image_layer):
    """Return friendly 1-based labels mapped to zero-based channel indices."""
    if image_layer is None:
        return []
    data = getattr(image_layer, "data", None)
    shape = tuple(getattr(data, "shape", ()))
    if len(shape) != 4:
        return []
    metadata = dict(getattr(image_layer, "metadata", {}) or {})
    names = tuple(metadata.get("channel_names", ()))
    if len(names) != shape[-1]:
        names = tuple(f"C{index + 1}" for index in range(shape[-1]))
    return [(f"{index + 1} — {name}", index) for index, name in enumerate(names)]


def bind_segmentation_channel_choices(function_widget):
    """Refresh a segmentation form's channel ComboBox when its Image changes."""

    def refresh(*_args):
        function_widget.channel_index.choices = segmentation_channel_choices(
            function_widget.image.value
        )

    function_widget.image.changed.connect(refresh)
    refresh()
    return refresh


def file_type_suffixes(label: str) -> tuple[str, ...]:
    """Map a napari batch UI label to concrete acquisition suffixes."""

    try:
        preset = _FILE_TYPE_TO_PRESET[label]
    except KeyError as exc:
        raise ValueError(f"unknown file type choice {label!r}") from exc
    return resolve_file_type_preset(preset)


def _set_tip(widget, key: str) -> None:
    widget.setToolTip(tip(key))


def _find_layer(viewer, name: str):
    layers = viewer.layers
    try:
        return layers[name]
    except (KeyError, TypeError, IndexError, ValueError):
        return next((layer for layer in layers if getattr(layer, "name", None) == name), None)


def make_segment_options_panel(
    viewer,
    QtWidgets,
    QtCore,
    *,
    capabilities: RuntimeCapabilities | None = None,
    on_status=None,
    get_image_start_dir=None,
    open_image_fn=None,
):
    """Shared mode/device/diameter controls for single-image and batch pages."""

    QWidget = QtWidgets.QWidget
    QVBoxLayout = QtWidgets.QVBoxLayout
    QHBoxLayout = QtWidgets.QHBoxLayout
    QLabel = QtWidgets.QLabel
    QComboBox = QtWidgets.QComboBox
    QCheckBox = QtWidgets.QCheckBox
    QDoubleSpinBox = QtWidgets.QDoubleSpinBox
    QSpinBox = QtWidgets.QSpinBox
    QPushButton = QtWidgets.QPushButton
    QFileDialog = QtWidgets.QFileDialog

    caps = capabilities or detect_runtime_capabilities()

    panel = QWidget()
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(0, 4, 0, 4)

    note = QLabel(caps.summary)
    note.setWordWrap(True)
    _set_tip(note, "cellpose_engine")
    layout.addWidget(note)

    tip_line = QLabel(
        "Hover any control for help. Diameter: Cellpose-SAM does not auto-estimate size — "
        "use Native, or open an image and measure a line."
    )
    tip_line.setWordWrap(True)
    layout.addWidget(tip_line)

    def _labeled_row(label_text: str, tooltip_key: str, field):
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        label = QLabel(label_text)
        _set_tip(label, tooltip_key)
        _set_tip(field, tooltip_key)
        row_layout.addWidget(label)
        row_layout.addWidget(field, 1)
        return row

    engine = QComboBox()
    for option in caps.available_engines:
        engine.addItem(option.label, option.engine_id)
    if engine.count() == 0:
        engine.addItem("No compatible Cellpose engine detected", None)
        engine.setEnabled(False)
    layout.addWidget(_labeled_row("Cellpose engine", "cellpose_engine", engine))

    # Show unavailable engines as a short note so users know what was filtered out.
    blocked = [opt for opt in caps.engines if not opt.available and opt.unavailable_reason]
    if blocked:
        blocked_note = QLabel(
            "Not offered here: "
            + "; ".join(f"{opt.label} ({opt.unavailable_reason})" for opt in blocked)
        )
        blocked_note.setWordWrap(True)
        layout.addWidget(blocked_note)

    mode = QComboBox()
    for label, value in SEGMENT_MODE_CHOICES:
        mode.addItem(label, value)
    layout.addWidget(_labeled_row("Segmentation mode", "segment_mode", mode))

    device = QComboBox()
    for option in caps.available_devices:
        device.addItem(option.label, option.device_id)
    # Select detected default (Auto→CPU when no GPU).
    default_device = caps.default_device_id
    for index in range(device.count()):
        if device.itemData(index) == default_device:
            device.setCurrentIndex(index)
            break
    layout.addWidget(_labeled_row("Device", "device", device))

    allow_cpu = QCheckBox("Allow CPU fallback if GPU fails")
    allow_cpu.setChecked(True)
    allow_cpu.setVisible(caps.cuda_available)
    _set_tip(allow_cpu, "allow_cpu_fallback")
    layout.addWidget(allow_cpu)

    diameter_mode = QComboBox()
    for label, value in DIAMETER_MODE_CHOICES:
        diameter_mode.addItem(label, value)
    layout.addWidget(_labeled_row("Diameter", "diameter_mode", diameter_mode))

    diameter = QDoubleSpinBox()
    diameter.setRange(1.0, 10000.0)
    diameter.setDecimals(1)
    diameter.setValue(30.0)
    diameter_row = _labeled_row("Diameter (px)", "diameter_px", diameter)
    layout.addWidget(diameter_row)

    measure_row = QWidget()
    measure_layout = QHBoxLayout(measure_row)
    measure_layout.setContentsMargins(0, 0, 0, 0)
    open_measure = QPushButton("Open image to measure…")
    add_measure = QPushButton("Add measure layer")
    use_measure = QPushButton("Use drawn line")
    _set_tip(open_measure, "open_measure_image")
    _set_tip(add_measure, "measure_diameter")
    _set_tip(use_measure, "measure_diameter")
    measure_layout.addWidget(open_measure)
    measure_layout.addWidget(add_measure)
    measure_layout.addWidget(use_measure)
    layout.addWidget(measure_row)

    stitch = QDoubleSpinBox()
    stitch.setRange(0.0, 1.0)
    stitch.setDecimals(3)
    stitch.setSingleStep(0.05)
    stitch.setValue(0.25)
    stitch_row = _labeled_row("Stitch threshold", "stitch_threshold", stitch)
    layout.addWidget(stitch_row)

    z_index = QSpinBox()
    z_index.setRange(0, 100000)
    z_index.setValue(0)
    z_row = _labeled_row("Z index (single plane)", "z_index", z_index)
    layout.addWidget(z_row)

    def sync_mode_fields(*_args):
        mode_value = mode.currentData()
        stitch_row.setVisible(mode_value == "stitch_2d")
        z_row.setVisible(mode_value == "single_plane_2d")

    def sync_diameter_fields(*_args):
        manual = diameter_mode.currentData() == "manual"
        diameter_row.setVisible(manual)
        measure_row.setVisible(manual)

    mode.currentIndexChanged.connect(sync_mode_fields)
    diameter_mode.currentIndexChanged.connect(sync_diameter_fields)
    sync_mode_fields()
    sync_diameter_fields()

    def open_image_to_measure():
        start = Path.home()
        if get_image_start_dir is not None:
            candidate = get_image_start_dir()
            if candidate is not None and Path(candidate).is_dir():
                start = Path(candidate)
        path, _ = QFileDialog.getOpenFileName(
            panel,
            "Choose an image to measure diameter",
            str(start),
            "Images (*.tif *.tiff *.nd2);;All files (*.*)",
        )
        if not path:
            return None
        if open_image_fn is None:
            raise RuntimeError("open_image_fn was not provided")
        open_image_fn(Path(path))
        if on_status is not None:
            on_status(
                f"Opened {Path(path).name}. Add a measure layer, draw a line across a typical "
                "nucleus, then click Use drawn line."
            )
        return Path(path)

    def add_measure_layer():
        existing = _find_layer(viewer, DIAMETER_SHAPES_LAYER)
        if existing is not None:
            viewer.layers.selection = [existing]
            if on_status is not None:
                on_status(
                    f"Use the line tool on '{DIAMETER_SHAPES_LAYER}', then click Use drawn line."
                )
            return existing
        layer = viewer.add_shapes(
            name=DIAMETER_SHAPES_LAYER,
            shape_type="line",
            edge_width=2,
            edge_color="cyan",
            face_color="transparent",
        )
        try:
            layer.mode = "add_line"
        except Exception:  # noqa: BLE001 - mode strings vary slightly by napari version
            try:
                layer.mode = "add_path"
            except Exception:  # noqa: BLE001
                pass
        if on_status is not None:
            on_status(
                f"Draw one line across a typical nucleus on '{DIAMETER_SHAPES_LAYER}', "
                "then click Use drawn line."
            )
        return layer

    def use_drawn_line():
        layer = _find_layer(viewer, DIAMETER_SHAPES_LAYER)
        length = diameter_from_shapes_layer(layer)
        diameter_mode.setCurrentIndex(
            next(i for i in range(diameter_mode.count()) if diameter_mode.itemData(i) == "manual")
        )
        diameter.setValue(round(length, 1))
        if on_status is not None:
            on_status(f"Diameter set to {length:.1f} px from the drawn line.")
        return length

    open_measure.clicked.connect(lambda: _safe_ui(open_image_to_measure, on_status))
    add_measure.clicked.connect(lambda: _safe_ui(add_measure_layer, on_status))
    use_measure.clicked.connect(lambda: _safe_ui(use_drawn_line, on_status))

    def overrides() -> dict:
        mode_value = mode.currentData()
        engine_value = engine.currentData()
        if engine_value is None:
            raise ValueError(
                "No compatible Cellpose engine is available in this environment. "
                "Install Cellpose 4.x into the CellQuant conda env."
            )
        if diameter_mode.currentData() == "native":
            diameter_value = None
        else:
            diameter_value = float(diameter.value())
        payload = {
            "engine": str(engine_value),
            "mode": mode_value,
            "device": device.currentData(),
            "allow_cpu_fallback": bool(allow_cpu.isChecked()) if caps.cuda_available else True,
            "diameter_px": diameter_value,
        }
        if mode_value == "stitch_2d":
            payload["stitch_threshold"] = float(stitch.value())
        elif mode_value == "single_plane_2d":
            payload["z_index"] = int(z_index.value())
        return payload

    panel.cellquant_overrides = overrides
    panel.cellquant_capabilities = caps
    panel.cellquant_engine = engine
    panel.cellquant_mode = mode
    panel.cellquant_device = device
    panel.cellquant_allow_cpu = allow_cpu
    panel.cellquant_diameter_mode = diameter_mode
    panel.cellquant_diameter = diameter
    return panel


def _safe_ui(action, on_status):
    try:
        return action()
    except Exception as exc:  # noqa: BLE001
        if on_status is not None:
            on_status(f"Diameter measure: {exc}")
        return None


def make_cellquant_widget(viewer=None):
    """Create the dock widget, importing GUI libraries only on demand."""
    import napari
    from magicgui import magicgui
    from napari.layers import Image, Labels
    from qtpy.QtCore import QTimer, Qt
    from qtpy import QtCore, QtWidgets
    from qtpy.QtWidgets import (
        QCheckBox,
        QComboBox,
        QHBoxLayout,
        QLabel,
        QProgressBar,
        QPushButton,
        QScrollArea,
        QSizePolicy,
        QStackedWidget,
        QVBoxLayout,
        QWidget,
    )

    viewer = viewer or napari.current_viewer()
    if viewer is None:
        raise RuntimeError("CellQuant requires an active napari viewer")
    controller = PluginController(viewer)
    # Prefetch the bundled template so single-image runs need no config browse.
    controller.set_config(load_config(default_template_config_path()))

    # Outer scrollable shell so the whole dock expands/scrolls in narrow side panels.
    root = QScrollArea()
    root.setWidgetResizable(True)
    root.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    root.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    root.setFrameShape(QtWidgets.QFrame.NoFrame)
    root.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    content = QWidget()
    layout = QVBoxLayout(content)
    layout.setContentsMargins(6, 6, 6, 6)
    status = QLabel("Ready — hover any control for help.")
    status.setWordWrap(True)
    status.setTextInteractionFlags(Qt.TextSelectableByMouse)
    status.setMinimumHeight(72)

    def set_status(text: str):
        controller.status_text = text
        status.setText(text)

    progress = QProgressBar()
    progress.setRange(0, 0)
    progress.hide()

    mode_row = QWidget()
    mode_layout = QHBoxLayout(mode_row)
    mode_layout.setContentsMargins(0, 0, 0, 0)
    mode_label = QLabel("Mode")
    _set_tip(mode_label, "workflow_mode")
    mode_layout.addWidget(mode_label)
    mode = QComboBox()
    mode.addItem("Single image", "single")
    mode.addItem("Batch folder", "batch")
    _set_tip(mode, "workflow_mode")
    mode_layout.addWidget(mode, 1)

    pages = QStackedWidget()
    pages.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
    single_page = QWidget()
    single_layout = QVBoxLayout(single_page)
    single_layout.setContentsMargins(0, 0, 0, 0)
    batch_page = QWidget()
    batch_layout = QVBoxLayout(batch_page)
    batch_layout.setContentsMargins(0, 0, 0, 0)

    layout_rows: dict[str, dict] = {}
    batch_paths = {"input": None, "output": None, "recursive": True, "file_type": FILE_TYPE_CHOICES[2]}
    forms: dict[str, object] = {"survey": None}
    capabilities = detect_runtime_capabilities()
    set_status(capabilities.summary)

    def get_image_start_dir():
        if batch_paths["input"] is not None:
            return batch_paths["input"]
        survey = forms.get("survey")
        if survey is not None:
            try:
                value = survey.input_dir.value
                path = Path(value)
                if path.is_dir() and str(path) not in {".", ""}:
                    return path
            except Exception:  # noqa: BLE001
                pass
        return Path.home()

    def open_image_for_measure(path: Path):
        return controller.open_path(require_existing_file(path, what="image"))

    single_options = make_segment_options_panel(
        viewer,
        QtWidgets,
        QtCore,
        capabilities=capabilities,
        on_status=set_status,
        get_image_start_dir=get_image_start_dir,
        open_image_fn=open_image_for_measure,
    )
    batch_options = make_segment_options_panel(
        viewer,
        QtWidgets,
        QtCore,
        capabilities=capabilities,
        on_status=set_status,
        get_image_start_dir=get_image_start_dir,
        open_image_fn=open_image_for_measure,
    )

    def _run(action):
        try:
            return action()
        except Exception as exc:  # noqa: BLE001 - surface sync UI failures in-dock
            controller.report_exception(exc)
            return None

    @magicgui(call_button="Open lazily", path={"mode": "r"})
    def open_image(path: Path, series: int = 0, position: int = 0):
        def action():
            source = require_existing_file(path, what="image")
            return controller.open_path(source, series=series, position=position)

        return _run(action)

    @magicgui(
        call_button="Run Cellpose",
        channel_index=SEGMENTATION_CHANNEL_WIDGET_OPTIONS,
    )
    def run_segmentation(image: Image, channel_index: int):
        def action():
            if controller.config is None:
                controller.set_config(load_config(default_template_config_path()))
            return controller.segment(
                image,
                channel_index=channel_index,
                segment_overrides=single_options.cellquant_overrides(),
            )

        return _run(action)

    bind_segmentation_channel_choices(run_segmentation)

    @magicgui(call_button="Measure edited labels + save", output_dir={"mode": "d"})
    def save_edited(labels: Labels, output_dir: Path):
        def action():
            destination = require_existing_dir(output_dir, what="output folder", create=True)
            if controller.config is None:
                config, path = materialize_run_config(
                    destination / "cellquant_run_config.yaml",
                    segment_channel=0,
                    segment_overrides=single_options.cellquant_overrides(),
                )
                controller.set_config(config)
                controller.last_config_path = path
            return controller.measure_and_save(destination, labels)

        return _run(action)

    @magicgui(
        call_button="Survey folder",
        input_dir={"mode": "d", "label": "Input folder"},
        output_dir={"mode": "d", "label": "Output folder"},
        file_type={"choices": list(FILE_TYPE_CHOICES), "label": "File type"},
    )
    def survey_batch(
        input_dir: Path,
        output_dir: Path,
        recursive: bool = True,
        file_type: str = "ND2 (.nd2)",
    ):
        def action():
            source = require_existing_dir(input_dir, what="input folder")
            destination = require_existing_dir(output_dir, what="output folder", create=True)
            batch_paths["input"] = source
            batch_paths["output"] = destination
            batch_paths["recursive"] = recursive
            batch_paths["file_type"] = file_type
            return controller.run_survey(
                source,
                destination,
                recursive=recursive,
                suffixes=file_type_suffixes(file_type),
                segment_overrides=batch_options.cellquant_overrides(),
            )

        return _run(action)

    forms["survey"] = survey_batch

    # magicgui tooltips (best-effort; widget attribute names are stable for these forms)
    for widget, key in (
        (open_image.path, "open_path"),
        (open_image.series, "series"),
        (open_image.position, "position"),
        (run_segmentation.image, "image_layer"),
        (run_segmentation.channel_index, "segmentation_channel"),
        (save_edited.labels, "image_layer"),
        (save_edited.output_dir, "output_dir"),
        (survey_batch.input_dir, "input_folder"),
        (survey_batch.output_dir, "batch_output_folder"),
        (survey_batch.recursive, "recursive"),
        (survey_batch.file_type, "file_type"),
    ):
        try:
            widget.tooltip = tip(key)
        except Exception:  # noqa: BLE001
            native = getattr(widget, "native", None)
            if native is not None:
                _set_tip(native, key)

    run_batch_button = QPushButton("Run batch")
    _set_tip(run_batch_button, "run_batch")

    def run_batch_clicked():
        def action():
            destination = batch_paths["output"]
            if destination is None:
                raise ValueError("Survey a folder first so the output path and run config are set")
            destination = require_existing_dir(destination, what="output folder", create=True)
            assignments = {}
            for layout_id, widgets in layout_rows.items():
                if not widgets["include"].isChecked():
                    continue
                assignments[layout_id] = int(widgets["channel"].currentData())
            if not assignments:
                raise ValueError("Include at least one surveyed layout and choose its channel")
            return controller.run_survey_batches(
                destination,
                assignments=assignments,
                segment_overrides=batch_options.cellquant_overrides(),
            )

        return _run(action)

    run_batch_button.clicked.connect(run_batch_clicked)

    layouts_host = QWidget()
    layouts_host_layout = QVBoxLayout(layouts_host)
    layouts_host_layout.setContentsMargins(0, 0, 0, 0)
    layouts_label = QLabel(
        "After Survey: choose the segmentation channel for each layout, then Run batch. "
        "Suggestions from channel names are optional defaults only. "
        "Hover controls for help. Config is written under <output>/survey/."
    )
    layouts_label.setWordWrap(True)
    _set_tip(layouts_label, "survey_layouts")
    layouts_host_layout.addWidget(layouts_label)
    layouts_body = QWidget()
    layouts_body_layout = QVBoxLayout(layouts_body)
    layouts_body_layout.setContentsMargins(0, 4, 0, 4)
    layouts_body_layout.setSpacing(10)
    layouts_host_layout.addWidget(layouts_body)

    def clear_layout_rows():
        layout_rows.clear()
        while layouts_body_layout.count():
            item = layouts_body_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def rebuild_layout_rows():
        clear_layout_rows()
        survey = controller.survey_result
        if survey is None:
            empty = QLabel("No survey yet — click Survey folder.")
            empty.setWordWrap(True)
            layouts_body_layout.addWidget(empty)
            return
        for layout_info in survey.layouts:
            row = QWidget()
            row_layout = QVBoxLayout(row)
            row_layout.setContentsMargins(0, 6, 0, 6)
            include = QCheckBox(
                f"{layout_info.file_count} file(s) · {layout_info.channel_count} ch · "
                f"{layout_info.layout_id}"
            )
            include.setChecked(layout_info.segment_channel is not None)
            _set_tip(include, "survey_layouts")
            names = QLabel("Channels: " + (" | ".join(layout_info.channel_names) or "(unnamed)"))
            names.setWordWrap(True)
            names.setTextInteractionFlags(Qt.TextSelectableByMouse)
            channel = QComboBox()
            channel.setMinimumHeight(28)
            _set_tip(channel, "segmentation_channel")
            for index, name in enumerate(layout_info.channel_names):
                channel.addItem(f"{index + 1} — {name}", index)
            preferred = layout_info.segment_channel
            if preferred is None:
                preferred = layout_info.suggested_channel
            if preferred is not None and 0 <= preferred < channel.count():
                channel.setCurrentIndex(preferred)
            row_layout.addWidget(include)
            row_layout.addWidget(names)
            row_layout.addWidget(channel)
            layouts_body_layout.addWidget(row)
            layout_rows[layout_info.layout_id] = {"include": include, "channel": channel}

    for native in (open_image.native, run_segmentation.native):
        single_layout.addWidget(native)
    single_layout.addWidget(single_options)
    single_layout.addWidget(save_edited.native)
    batch_layout.addWidget(survey_batch.native)
    batch_layout.addWidget(batch_options)
    batch_layout.addWidget(layouts_host)
    batch_layout.addWidget(run_batch_button)
    pages.addWidget(single_page)
    pages.addWidget(batch_page)

    def sync_mode(index: int):
        pages.setCurrentIndex(index)
        label = mode.itemText(index)
        set_status(f"Mode: {label}")

    mode.currentIndexChanged.connect(sync_mode)

    actions = QWidget()
    actions_layout = QHBoxLayout(actions)
    actions_layout.setContentsMargins(0, 0, 0, 0)
    cancel = QPushButton("Cancel")
    _set_tip(cancel, "cancel")
    cancel.clicked.connect(controller.cancel)
    open_output = QPushButton("Open output folder")
    _set_tip(open_output, "open_output")
    open_failures = QPushButton("Open failures.csv")
    _set_tip(open_failures, "open_failures")

    def _open_guarded(path: Path | None, missing: str):
        try:
            if path is None:
                raise FileNotFoundError(missing)
            open_path_in_os(path)
        except Exception as exc:  # noqa: BLE001
            controller.report_exception(exc)

    def open_output_clicked():
        _open_guarded(controller.last_output_dir, "No output folder from the latest CellQuant run yet")

    def open_failures_clicked():
        path = controller.last_failures_path
        if path is None and controller.last_output_dir is not None:
            candidate = Path(controller.last_output_dir) / "failures.csv"
            path = candidate if candidate.exists() else None
        _open_guarded(path, "No failures.csv from the latest batch yet")

    open_output.clicked.connect(open_output_clicked)
    open_failures.clicked.connect(open_failures_clicked)
    actions_layout.addWidget(cancel)
    actions_layout.addWidget(open_output)
    actions_layout.addWidget(open_failures)

    def display_event(event):
        if event.current is not None:
            progress.show()
            progress.setRange(0, max(event.total, 1))
            progress.setValue(event.current)
        if event.kind in {"stage_finished", "cancelled", "failed"}:
            if event.stage != "batch":
                progress.hide()

    def refresh_action_buttons():
        open_output.setEnabled(controller.last_output_dir is not None)
        has_failures = controller.last_failures_path is not None and Path(
            controller.last_failures_path
        ).exists()
        if not has_failures and controller.last_output_dir is not None:
            has_failures = (Path(controller.last_output_dir) / "failures.csv").exists()
        open_failures.setEnabled(bool(has_failures))
        run_batch_button.setEnabled(controller.survey_result is not None)

    last_survey_token = {"value": None}

    def poll_events():
        controller.drain_events(display_event)
        status.setText(controller.status_text)
        refresh_action_buttons()
        survey = controller.survey_result
        token = None if survey is None else (survey.surveyed_utc, len(survey.layouts))
        if token != last_survey_token["value"]:
            last_survey_token["value"] = token
            rebuild_layout_rows()

    timer = QTimer(content)
    timer.timeout.connect(poll_events)
    timer.start(50)

    layout.addWidget(mode_row)
    layout.addWidget(pages)
    layout.addWidget(actions)
    layout.addWidget(progress)
    layout.addWidget(status)
    layout.addStretch(1)
    root.setWidget(content)

    root.cellquant_controller = controller
    root.cellquant_timer = timer
    root.cellquant_mode = mode
    root.cellquant_pages = pages
    root.cellquant_survey_batch = survey_batch
    root.cellquant_open_output = open_output
    root.cellquant_open_failures = open_failures
    root.cellquant_single_options = single_options
    root.cellquant_batch_options = batch_options
    root.cellquant_content = content
    sync_mode(0)
    refresh_action_buttons()
    return root


def cellquant_widget():
    """Zero-argument npe2 widget entry point."""
    return make_cellquant_widget()


__all__ = [
    "DIAMETER_MODE_CHOICES",
    "FILE_TYPE_CHOICES",
    "SEGMENTATION_CHANNEL_WIDGET_OPTIONS",
    "SEGMENT_MODE_CHOICES",
    "bind_segmentation_channel_choices",
    "cellquant_widget",
    "file_type_suffixes",
    "make_cellquant_widget",
    "make_segment_options_panel",
    "segmentation_channel_choices",
]
