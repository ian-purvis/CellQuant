param(
    [string]$Prefix = '',
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $ProjectRoot

. (Join-Path $PSScriptRoot 'resolve_conda.ps1')
. (Join-Path $PSScriptRoot 'resolve_env_location.ps1')

$CondaExe = Resolve-CondaExecutable
$DefaultPrefix = Get-DefaultCellQuantEnvPrefix -CondaExe $CondaExe
$SavedPrefix = Read-CellQuantEnvPrefix -ProjectRoot $ProjectRoot

if (-not $Prefix) {
    if (-not $NonInteractive) {
        Write-Host ''
        Write-Host 'CellQuant install location'
        Write-Host '--------------------------'
        Write-Host 'Napari and the CellQuant conda environment will be installed'
        Write-Host 'into one folder (a conda env prefix). Choose any writable path.'
        Write-Host ''
        if ($SavedPrefix) {
            Write-Host "Last used:  $SavedPrefix"
        }
        Write-Host "Default:    $DefaultPrefix"
        Write-Host ''
        $Answer = Read-Host 'Install folder (Enter = default, or paste a full path)'
        if ($Answer -and $Answer.Trim()) {
            $Prefix = $Answer.Trim().Trim('"')
        }
    }
}

if (-not $Prefix) {
    if ($SavedPrefix) {
        $Prefix = $SavedPrefix
        Write-Host "Using previously saved location: $Prefix"
    } else {
        $Prefix = $DefaultPrefix
        Write-Host "Using default location: $Prefix"
    }
}

$Prefix = Save-CellQuantEnvPrefix -ProjectRoot $ProjectRoot -Prefix $Prefix
$parent = Split-Path -Parent $Prefix
if ($parent -and -not (Test-Path -LiteralPath $parent)) {
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
}

Write-Host ''
Write-Host "Installing CellQuant environment at:"
Write-Host "  $Prefix"
Write-Host 'This can take several minutes...'
Write-Host ''

$EnvFile = Join-Path $ProjectRoot 'environment.yml'
if (Test-Path -LiteralPath $Prefix) {
    & $CondaExe env update --prefix $Prefix --file $EnvFile --prune
} else {
    & $CondaExe env create --prefix $Prefix --file $EnvFile
}
if ($LASTEXITCODE -ne 0) {
    throw "Conda environment install/update failed with exit code $LASTEXITCODE"
}

Write-Host ''
Write-Host "Installed at: $Prefix"
Write-Host 'Location saved to cellquant_env.json for Open CellQuant.bat.'
Write-Host 'Double-click Open CellQuant.bat (or run scripts\launch_napari.ps1).'
