# Shared helpers for CellQuant Windows env location (prefix-based conda envs).

$script:CellQuantEnvMarkerName = 'cellquant_env.json'

function Get-CellQuantEnvMarkerPath {
    param([Parameter(Mandatory)][string]$ProjectRoot)
    Join-Path $ProjectRoot $script:CellQuantEnvMarkerName
}

function Get-DefaultCellQuantEnvPrefix {
    param([Parameter(Mandatory)][string]$CondaExe)

    $Base = $null
    try {
        $InfoJson = & $CondaExe info --json 2>$null
        if ($LASTEXITCODE -eq 0 -and $InfoJson) {
            $Info = $InfoJson | ConvertFrom-Json
            if ($Info.root_prefix) {
                $Base = [string]$Info.root_prefix
            } elseif ($Info.conda_prefix) {
                $Base = [string]$Info.conda_prefix
            }
        }
    } catch {
        $Base = $null
    }

    if ($Base) {
        return (Join-Path $Base 'envs\cellquant-napari')
    }
    if ($env:USERPROFILE) {
        return (Join-Path $env:USERPROFILE 'cellquant-napari')
    }
    return (Join-Path (Get-Location) 'cellquant-napari')
}

function Read-CellQuantEnvPrefix {
    param([Parameter(Mandatory)][string]$ProjectRoot)

    $MarkerPath = Get-CellQuantEnvMarkerPath -ProjectRoot $ProjectRoot
    if (-not (Test-Path -LiteralPath $MarkerPath -PathType Leaf)) {
        return $null
    }

    $Raw = Get-Content -LiteralPath $MarkerPath -Raw -ErrorAction Stop
    $Data = $Raw | ConvertFrom-Json
    if (-not $Data.prefix) {
        return $null
    }
    return [string]$Data.prefix
}

function Save-CellQuantEnvPrefix {
    param(
        [Parameter(Mandatory)][string]$ProjectRoot,
        [Parameter(Mandatory)][string]$Prefix
    )

    $Resolved = [System.IO.Path]::GetFullPath($Prefix)
    $MarkerPath = Get-CellQuantEnvMarkerPath -ProjectRoot $ProjectRoot
    $Payload = @{
        prefix = $Resolved
        updated_utc = (Get-Date).ToUniversalTime().ToString('o')
    } | ConvertTo-Json
    Set-Content -LiteralPath $MarkerPath -Value $Payload -Encoding UTF8
    return $Resolved
}

function Resolve-CellQuantEnvPrefix {
    param(
        [Parameter(Mandatory)][string]$ProjectRoot,
        [string]$Prefix,
        [Parameter(Mandatory)][string]$CondaExe,
        [switch]$AllowDefault
    )

    if ($Prefix) {
        return [System.IO.Path]::GetFullPath($Prefix.Trim().Trim('"'))
    }

    $Saved = Read-CellQuantEnvPrefix -ProjectRoot $ProjectRoot
    if ($Saved) {
        return [System.IO.Path]::GetFullPath($Saved)
    }

    if ($AllowDefault) {
        return Get-DefaultCellQuantEnvPrefix -CondaExe $CondaExe
    }

    return $null
}
