param(
    [string]$Prefix = ''
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $ProjectRoot

. (Join-Path $PSScriptRoot 'resolve_conda.ps1')
. (Join-Path $PSScriptRoot 'resolve_env_location.ps1')

try {
    $CondaExe = Resolve-CondaExecutable
} catch {
    Write-Host ''
    Write-Host 'Conda was not found.' -ForegroundColor Red
    Write-Host 'Install Miniconda or Miniforge, then run Install CellQuant.bat.'
    Write-Host "Details: $($_.Exception.Message)"
    exit 1
}

$ResolvedPrefix = Resolve-CellQuantEnvPrefix `
    -ProjectRoot $ProjectRoot `
    -Prefix $Prefix `
    -CondaExe $CondaExe `
    -AllowDefault:$false

if (-not $ResolvedPrefix) {
    Write-Host ''
    Write-Host 'No CellQuant install location is recorded yet.' -ForegroundColor Red
    Write-Host 'Run Install CellQuant.bat once and choose (or accept) an install folder.'
    exit 1
}

if (-not (Test-Path -LiteralPath $ResolvedPrefix)) {
    Write-Host ''
    Write-Host "Install folder not found: $ResolvedPrefix" -ForegroundColor Red
    Write-Host 'Run Install CellQuant.bat again, or pick a different folder.'
    exit 1
}

Write-Host "Launching napari from:"
Write-Host "  $ResolvedPrefix"
& $CondaExe run --no-capture-output -p $ResolvedPrefix napari
exit $LASTEXITCODE
