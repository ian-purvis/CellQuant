from __future__ import annotations

import logging
import os
from collections.abc import Sequence
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    cast,
    overload,
)

from . import PluginManager
from .manifest.utils import v1_to_v2
from .types import FullLayerData, LayerData, PathLike

if TYPE_CHECKING:
    import napari.layers

    from .manifest.contributions import ReaderContribution, WriterContribution
logger = logging.getLogger(__name__)


def _normalize_paths(paths: PathLike | Sequence[PathLike]) -> str | list[str]:
    """Normalise ``PathLike`` input to ``str`` for downstream/plugin use.

    npe2 accepts ``str`` or ``pathlib.Path`` at its public API, but reader and
    writer plugins (and the internal matching logic) expect ``str``. ``Path``
    objects are converted with ``os.fspath``; ``str`` (including remote URLs)
    is returned unchanged.
    """
    if isinstance(paths, (str, os.PathLike)):
        return os.fspath(paths)
    return [os.fspath(p) for p in paths]


def read(
    paths: Sequence[PathLike], *, stack: bool, plugin_name: str | None = None
) -> list[LayerData]:
    """Try to read file at `path`, with plugins offering a ReaderContribution.

    Parameters
    ----------
    paths : list of str or pathlib.Path
        Path to the file or resource being read.
    stack : bool
        Should the readers stack the read files.
    plugin_name : str, optional
        Optional plugin name.  If provided, only readers from this plugin will be
        tried (it's possible that none will be compatible). by default None

    Returns
    -------
    List[LayerData]
        If a compatible reader is found and executed, a list of LayerDataTuples is
        returned

    Raises
    ------
    ValueError
        If no readers are found or none return data
    """
    return _read(paths, plugin_name=plugin_name, stack=stack)


def read_get_reader(
    path: PathLike | Sequence[PathLike],
    *,
    plugin_name: str | None = None,
    stack: bool | None = None,
) -> tuple[list[LayerData], ReaderContribution]:
    """Variant of `read` that also returns the `ReaderContribution` used."""
    # normalise Path -> str before the assertions / dispatch below
    path = _normalize_paths(path)
    if stack is None:
        # "npe1" old path
        # Napari 0.4.15 and older, hopefully we can drop this and make stack mandatory
        new_path, new_stack = v1_to_v2(path)
        return _read(
            new_path, plugin_name=plugin_name, return_reader=True, stack=new_stack
        )
    else:
        assert isinstance(path, list)
        for p in path:
            assert isinstance(p, str)
        return _read(path, plugin_name=plugin_name, return_reader=True, stack=stack)


def write(
    path: PathLike,
    layer_data: list[FullLayerData | napari.layers.Layer],
    *,
    plugin_name: str | None = None,
) -> list[str]:
    """Write layer_data tuples to `path`.

    Parameters
    ----------
    path : str or pathlib.Path
        The path (file, directory, url) to write.
    layer_data : list of layer data tuples
        List of tuples in the form (data, metadata_dict, layer_type_string)
    plugin_name : str, optional
        Name of the plugin to write data with. If `None` then all plugins
        corresponding to appropriate hook specification will be looped
        through to find the first one that can write the data.

    Returns
    -------
    list of str
        List of file paths that were written

    Raises
    ------
    ValueError
        If no suitable writers are found.
    """
    return _write(path, layer_data, plugin_name=plugin_name)


def write_get_writer(
    path: PathLike,
    layer_data: list[FullLayerData | napari.layers.Layer],
    *,
    plugin_name: str | None = None,
) -> tuple[list[str], WriterContribution]:
    """Variant of write that also returns the `WriterContribution` used."""
    return _write(path, layer_data, plugin_name=plugin_name, return_writer=True)


# -----------------------------------------------------------------------------------


@overload
def _read(
    paths: PathLike | Sequence[PathLike],
    *,
    stack: bool,
    plugin_name: str | None = None,
    return_reader: Literal[False] = False,
    _pm=None,
) -> list[LayerData]: ...


@overload
def _read(
    paths: PathLike | Sequence[PathLike],
    *,
    stack: bool,
    plugin_name: str | None = None,
    return_reader: Literal[True],
    _pm=None,
) -> tuple[list[LayerData], ReaderContribution]: ...


def _read(
    paths: PathLike | Sequence[PathLike],
    *,
    stack: bool,
    plugin_name: str | None = None,
    return_reader: bool = False,
    _pm: PluginManager | None = None,
) -> tuple[list[LayerData], ReaderContribution] | list[LayerData]:
    """Execute the `read...` functions above."""
    if _pm is None:
        _pm = PluginManager.instance()

    # normalise Path -> str so reader plugins receive str
    paths = _normalize_paths(paths)

    # get readers compatible with paths and chosen plugin - raise errors if
    # choices are invalid or there's nothing to try
    chosen_compatible_readers = _get_compatible_readers_by_choice(
        plugin_name, paths, _pm
    )
    assert chosen_compatible_readers, (
        "No readers to try. Expected an exception before this point."
    )

    tried_reader = False
    for rdr in chosen_compatible_readers:
        read_func = rdr.exec(
            kwargs={"path": paths, "stack": stack, "_registry": _pm.commands}
        )
        # ── Path A: reader refused the file ──────────────────────────────
        # rdr.exec() returned None -> the reader is skipped; tried_reader stays False.
        if read_func is None:
            continue

        # ── Path B: reader returned a callable -> actually read ───────────
        tried_reader = True
        # if the reader function raises an exception here, we don't catch
        # instead, it propagates to the caller.
        layer_data = read_func(paths, stack=stack)

        # ── null layer sentinel [(None,)] ─────────────────────
        # The reader accepted the file and processed it successfully, but
        # has no layer data to return. This is a documented contract value
        # used e.g. by napari's built-in .py reader (scripts modify the
        # viewer directly) and by third-party plugins that handle files
        # through non-layer pathways, like opening a widget.
        if plugin_name and _is_null_layer_sentinel(layer_data):
            logger.debug(
                f"Reader {plugin_name!r} was selected to open {paths!r}, "
                "and opened no layers. This may be intentional. If you "
                "expected layers to be opened, contact the plugin author."
            )

        # ── reader returns truthy ────────────────────
        # layer_data is truthy (non-empty list). Return immediately (success).
        # Covers both null layer sentinel [(None,)]
        # and genuine [(data, meta, layer_type)] tuples.
        if layer_data:
            return (layer_data, rdr) if return_reader else layer_data

    # ── No reader succeeded ──────────────────────────────────────────────
    if plugin_name:
        if tried_reader:
            # Path B was reached (reader accepted the file) but the reader
            # function returned falsy data (e.g. []) or raised and was caught.
            raise ValueError(
                f"Reader {plugin_name!r} was selected to open "
                + f"{paths!r}, but returned no data."
            )
        else:
            # Path A for all readers — none of them accepted the file.
            raise ValueError(
                f"Reader {plugin_name!r} was selected to open "
                + f"{paths!r}, but refused the file."
            )
    # No plugin was specified and no reader returned data (all Path B
    # returns were skipped because layer_data was falsy).
    raise ValueError(f"No readers returned data for {paths!r}")


def _get_compatible_readers_by_choice(
    plugin_name: str | None,
    paths: PathLike | Sequence[PathLike],
    pm: PluginManager,
):
    """Returns compatible readers filtered by validated plugin choice.

    Checks that plugin_name is an existing plugin (and command if
    a specific contribution was passed), and that it is compatible
    with paths. Raises ValueError if given plugin doesn't exist,
    it is not compatible with the given paths, or no compatible
    readers can be found for paths (if no plugin was chosen).

    Parameters
    ----------
    plugin_name: Union[str, None]
        name of chosen plugin, or None
    paths: Union[str, Sequence[str]]
        paths to read
    pm: PluginManager
        plugin manager instance to check for readers

    Raises
    ------
    ValueError
        If the given reader doesn't exist
    ValueError
        If there are no compatible readers
    ValueError
        If the given reader is not compatible

    Returns
    -------
    compat_readers : List[ReaderContribution]
        Compatible readers for plugin choice
    """
    passed_contrib = plugin_name and ("." in plugin_name)
    compat_readers = list(pm.iter_compatible_readers(paths))
    compat_reader_names = sorted(
        {(rdr.command if passed_contrib else rdr.plugin_name) for rdr in compat_readers}
    )
    helper_error_message = (
        f"Available readers for {paths!r} are: {compat_reader_names!r}."
        if compat_reader_names
        else f"No compatible readers are available for {paths!r}."
    )

    # check whether plugin even exists.
    if plugin_name:
        try:
            # note that get_manifest works with a full command e.g. my-plugin.my-reader
            pm.get_manifest(plugin_name)
            if passed_contrib:
                pm.get_command(plugin_name)
        except KeyError:
            raise ValueError(
                f"Given reader {plugin_name!r} does not exist. {helper_error_message}"
            ) from None

    # no choice was made and there's no readers to try
    if not plugin_name and not len(compat_reader_names):
        raise ValueError(helper_error_message)

    # user didn't make a choice and we have some readers to try, return them
    if not plugin_name:
        return compat_readers

    # user made a choice and it exists, but it may not be a compatible reader
    plugin, _, _ = plugin_name.partition(".")
    chosen_compatible_readers = [
        rdr
        for rdr in compat_readers
        if rdr.plugin_name == plugin
        and (not passed_contrib or rdr.command == plugin_name)
    ]
    # the user's choice is not compatible with the paths. let them know what is
    if not chosen_compatible_readers:
        raise ValueError(
            f"Given reader {plugin_name!r} is not a compatible reader for {paths!r}. "
            + helper_error_message
        )
    return chosen_compatible_readers


def _is_null_layer_sentinel(layer_data: Any) -> bool:
    """Checks if the layer data returned from a reader function indicates an
    empty file. The sentinel value used for this is ``[(None,)]``.

    Parameters
    ----------
    layer_data : LayerData
        The layer data returned from a reader function to check

    Returns
    -------
    bool
        True, if the layer_data indicates an empty file, False otherwise
    """
    return (
        isinstance(layer_data, list)
        and len(layer_data) == 1
        and isinstance(layer_data[0], tuple)
        and len(layer_data[0]) == 1
        and layer_data[0][0] is None
    )


@overload
def _write(
    path: PathLike,
    layer_data: list[FullLayerData | napari.layers.Layer],
    *,
    plugin_name: str | None = None,
    return_writer: Literal[False] = False,
    _pm: PluginManager | None = None,
) -> list[str]: ...


@overload
def _write(
    path: PathLike,
    layer_data: list[FullLayerData | napari.layers.Layer],
    *,
    plugin_name: str | None = None,
    return_writer: Literal[True],
    _pm: PluginManager | None = None,
) -> tuple[list[str], WriterContribution]: ...


def _write(
    path: PathLike,
    layer_data: list[FullLayerData | napari.layers.Layer],
    *,
    plugin_name: str | None = None,
    return_writer: bool = False,
    _pm: PluginManager | None = None,
) -> list[str] | tuple[list[str], WriterContribution]:
    if not layer_data:
        raise ValueError("Must provide layer data")
    if _pm is None:
        _pm = PluginManager.instance()

    # normalise Path -> str so writer plugins receive str
    path = os.fspath(path)

    _layer_tuples: list[FullLayerData] = [
        (
            cast("napari.layers.Layer", x).as_layer_data_tuple()
            if hasattr(x, "as_layer_data_tuple")
            else x
        )
        for x in layer_data
    ]
    layer_types = [x[2] for x in _layer_tuples]
    writer, new_path = _pm.get_writer(
        path, layer_types=layer_types, plugin_name=plugin_name
    )

    if not writer:
        raise ValueError(f"No writer found for {path!r} with layer types {layer_types}")

    # Writers that take at most one layer must use the single-layer api.
    # Otherwise, they must use the multi-layer api.
    n = sum(ltc.max() for ltc in writer.layer_type_constraints())
    args = (new_path, *_layer_tuples[0][:2]) if n <= 1 else (new_path, _layer_tuples)
    res = writer.exec(args=args)

    # napari_get_writer-style writers don't always return a list
    # though strictly speaking they should?
    result = [res] if isinstance(res, str) else res or []
    return (result, writer) if return_writer else result
