import keyword
import re

_package_name = "([A-Z0-9]|[A-Z0-9][A-Z0-9._-]*[A-Z0-9])"
_python_identifier = "([a-zA-Z_][a-zA-Z_0-9]*)"

# how do we deal with keywords ?
# do we try to validate ? Or do we just
# assume users won't try to create a command named
# `npe2_tester.False.if.for.in` ?
_identifier_plus_dash = "(?:[a-zA-Z_][a-zA-Z_0-9-]+)"
_dotted_name = f"(?:(?:{_identifier_plus_dash}\\.)*{_identifier_plus_dash})"
PACKAGE_NAME_PATTERN = re.compile(f"^{_package_name}$", re.IGNORECASE)
DOTTED_NAME_PATTERN = re.compile(_dotted_name)
DISPLAY_NAME_PATTERN = re.compile(r"^[^\W_][\w -~:.'\"]{1,88}[^\W_]$")
PYTHON_NAME_PATTERN = re.compile(f"^({_dotted_name}):({_dotted_name})$")
COMMAND_ID_PATTERN = re.compile(
    f"^(({_package_name}\\.)*{_python_identifier})$", re.IGNORECASE
)


def command_id(id: str) -> str:
    if id and not COMMAND_ID_PATTERN.match(id):
        raise ValueError(
            f"{id!r} is not a valid command id. It must begin with the package name "
            "followed by a period, then may can only contain alphanumeric "
            "characters and underscores."
        )
    return id


def package_name(name: str) -> str:
    """Assert that `name` is a valid package name in accordance with PEP-0508."""
    if name and not PACKAGE_NAME_PATTERN.match(name):
        raise ValueError(
            f"{name!r} is not a valid python package name. "
            "See https://peps.python.org/pep-0508/#names "
        )
    return name


def python_name(name: str) -> str:
    """Assert that `name` is a valid python name: e.g. `module.submodule:funcname`"""
    if name and not PYTHON_NAME_PATTERN.match(name):
        msg = (
            f"{name!r} is not a valid python_name.  A python_name must "
            "be of the form '{obj.__module__}:{obj.__qualname__}' (e.g. "
            "'my_package.a_module:some_function')."
        )
        if ".<locals>." in name:
            *_, a, b = name.split(".<locals>.")
            a = a.split(":")[-1]
            msg += (
                " Note: functions defined in local scopes are not yet supported. "
                f"Please move function {b!r} to the global scope of module {a!r}"
            )
        raise ValueError(msg)
    return name


def display_name(v: str) -> str:
    if not DISPLAY_NAME_PATTERN.match(v):
        raise ValueError(
            f"{v} is not a valid display_name. It must be 3-90 characters long, "
            "and must not begin or end with an underscore, white space, or "
            "non-word character."
        )
    return v


def _ensure_valid_resource(value):
    if "/" in value or (value.count(":") != 1 and value.count(".") != 1):
        raise ValueError(
            f"{value} is not a valid fonticon or iconify key, nor a path in the form "
            "`package:resource`, where `package` and `resource` are arguments to "
            "`importlib.resources.path(package, resource)` "
            "(e.g. `my_plugin.some_module:my_logo.png`). This resource must be "
            "shipped with the sdist)"
        )


def configuration_key(key: str) -> str:
    """Assert that `key` is usable as a pydantic field / attribute name.

    Configuration and property keys become attribute names on the settings
    model generated from the manifest (e.g.
    `get_plugin_settings('plugin').key.subkey`), so they must be valid,
    non-reserved Python identifiers that do not begin with an underscore
    (leading underscores are treated as private attributes by pydantic).
    """
    if not key.isidentifier() or keyword.iskeyword(key) or key.startswith("_"):
        raise ValueError(
            f"{key!r} is not a valid configuration key. Configuration and "
            "property keys become attribute names on the generated settings "
            "model, so they must be valid, non-reserved Python identifiers "
            "that do not begin with an underscore."
        )
    return key


def validate_icon(value):
    if value is None:
        return None
    if isinstance(value, str):
        _ensure_valid_resource(value)
    if light_url := getattr(value, "light", None):
        _ensure_valid_resource(light_url)
    if dark_url := getattr(value, "dark", None):
        _ensure_valid_resource(dark_url)
    return value
